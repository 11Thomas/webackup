#!/usr/bin/env bash
# ============================================================================
# 在飞牛 fnOS 终端直接出 .fpk（无需本机 Docker / GitHub / 外网镜像仓库）
# ----------------------------------------------------------------------------
# 前置条件：飞牛 NAS 能联网（至少能拉取一次 Docker Hub 的基础镜像）。
#           （判断方法：你能在飞牛「应用中心」正常安装官方应用，就说明能联网）
#
# 用法：
#   1) 把整个 webackup 工程传到飞牛任意目录（用飞牛文件管理拖进去，或 git clone）
#   2) 打开飞牛「终端」App（或 SSH 进飞牛），进入工程目录
#   3) 执行： bash scripts/build-on-fnos.sh
#   4) 等它跑完，按屏幕提示去「应用中心 → 手动安装」选生成的 .fpk
# ============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

TAG="${TAG:-0.1.0}"
LOCAL_IMG="webackup:${TAG}"
REG_IMG="127.0.0.1:5000/webackup:${TAG}"

echo "==> 检查环境（docker / fnpack）"
if ! command -v docker >/dev/null 2>&1; then
  echo "未找到 docker。请确认飞牛已安装 Docker 套件，并在飞牛「终端」中运行本脚本。"
  exit 1
fi
if ! command -v fnpack >/dev/null 2>&1; then
  echo "未找到 fnpack。飞牛 fnOS 应自带 fnpack；若提示找不到，请用绝对路径调用（见 README）。"
  exit 1
fi

echo "==> 构建应用镜像（首次需联网拉 node:22-slim，约百 MB，耐心等）"
docker build --platform linux/amd64 -t "$LOCAL_IMG" -f Dockerfile .

echo "==> 启动本地镜像仓库（让 .fpk 安装时不依赖外网仓库）"
if ! docker inspect webackup-reg >/dev/null 2>&1; then
  docker run -d --name webackup-reg --restart=always -p 5000:5000 registry:2
fi
docker tag "$LOCAL_IMG" "$REG_IMG"
docker push "$REG_IMG"

echo "==> 把 compose 的镜像地址改为本地仓库"
if grep -q "__WEBACKUP_IMAGE__" deploy/fnos/app/docker/docker-compose.yaml; then
  sed -i "s#__WEBACKUP_IMAGE__#$REG_IMG#" deploy/fnos/app/docker/docker-compose.yaml
else
  echo "（compose 镜像地址已设置，跳过）"
fi

echo "==> 使用飞牛自带 fnpack 打包"
fnpack build deploy/fnos || fnpack build
echo ""
echo "完成 ✅  请在飞牛「应用中心 → 手动安装」选择生成的 webackup-${TAG}.fpk"
echo "提示：本地仓库容器 webackup-reg 已设 --restart=always，飞牛重启后通常会自动拉起；"
echo "      若安装时提示拉不到镜像，先确认 webackup-reg 容器在运行（docker ps | grep webackup-reg）。"
