#!/usr/bin/env bash
# 构建并打包 WeBackup 飞牛 .fpk
# 前置：本机已安装 docker 与 fnpack（https://developer.fnnas.com/），且可推送镜像到镜像仓库。
# 用法：
#   REGISTRY=ghcr.io REPO=webackup/webackup TAG=v0.1.0 FNPACK_BIN=/usr/local/bin/fnpack ./scripts/build-fpk.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_DIR="$ROOT/deploy/fnos"
OUT_DIR="$ROOT/dist-fpk"
mkdir -p "$OUT_DIR"

REGISTRY="${REGISTRY:-ghcr.io}"
REPO="${REPO:-webackup/webackup}"
TAG="${TAG:-$(node -p "require('$ROOT/package.json').version")}"
IMAGE="$REGISTRY/$REPO:$TAG"

echo "==> 构建并推送镜像: $IMAGE"
# fnOS 三方应用目前仅 x86_64，强制构建 linux/amd64（避免 Apple Silicon 误出 arm64）
docker build --platform linux/amd64 -t "$IMAGE" -f "$ROOT/Dockerfile" "$ROOT"
docker push "$IMAGE"

echo "==> 复制打包目录到临时构建区（保持仓库内占位符不被污染）"
BUILD_DIR="$(mktemp -d)"
cp -r "$PKG_DIR/." "$BUILD_DIR/"

echo "==> 将 compose 镜像占位符 __WEBACKUP_IMAGE__ 替换为: $IMAGE"
node -e "const fs=require('fs');const p='$BUILD_DIR/app/docker/docker-compose.yaml';let s=fs.readFileSync(p,'utf8');s=s.split('__WEBACKUP_IMAGE__').join('$IMAGE');fs.writeFileSync(p,s);"
echo "    替换后: $(grep 'image:' "$BUILD_DIR/app/docker/docker-compose.yaml")"

echo "==> 确保生命周期脚本可执行"
chmod +x "$BUILD_DIR/cmd/"*

FNPACK="${FNPACK_BIN:-fnpack}"
echo "==> 运行 fnpack build"
( cd "$BUILD_DIR" && "$FNPACK" build )

echo "==> 收集产物到 $OUT_DIR"
shopt -s nullglob
for f in "$BUILD_DIR"/*.fpk; do mv -f "$f" "$OUT_DIR/"; done
shopt -u nullglob

echo "==> 完成。产物："
ls -la "$OUT_DIR"
echo "    然后在飞牛『应用中心 → 手动安装』上传该 .fpk 即可。"
