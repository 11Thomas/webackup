// tools/gen-icons.mjs — 生成应用图标占位图（纯 zlib，无依赖）
import zlib from 'node:zlib';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const CRC = (() => {
  const t = [];
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const t = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([t, data])));
  return Buffer.concat([len, t, data, crc]);
}
function png(size) {
  const w = size, h = size;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  let o = 0;
  for (let y = 0; y < h; y++) {
    raw[o++] = 0;
    for (let x = 0; x < w; x++) {
      const dx = x - w / 2, dy = y - h / 2;
      const r = Math.sqrt(dx * dx + dy * dy);
      let R = 47, G = 107, B = 255; // 品牌蓝
      if (r < w * 0.30) { R = 255; G = 255; B = 255; } // 白色气泡
      raw[o++] = R; raw[o++] = G; raw[o++] = B; raw[o++] = 255;
    }
  }
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([sig, chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

const out = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'deploy', 'fnos');
fs.mkdirSync(path.join(out, 'app', 'ui', 'images'), { recursive: true });
fs.writeFileSync(path.join(out, 'ICON.PNG'), png(64));
fs.writeFileSync(path.join(out, 'ICON_256.PNG'), png(256));
fs.writeFileSync(path.join(out, 'app', 'ui', 'images', 'icon-64.png'), png(64));
fs.writeFileSync(path.join(out, 'app', 'ui', 'images', 'icon-256.png'), png(256));
console.log('已生成 ICON.PNG / ICON_256.PNG / app/ui/images/icon-64.png / icon-256.png');
