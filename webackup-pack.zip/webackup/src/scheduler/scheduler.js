// scheduler/scheduler.js — 轻量定时调度（纯标准库，无外部 cron 依赖）
// 支持 schedule 形式：
//   daily HH:MM
//   weekly <MON..SUN> HH:MM
//   monthly <1-28> HH:MM
//   interval <分钟>
//   cron <分> <时> <日> <月> <周>   (标准 5 段 cron，* 与 , 列表)
const WEEK = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

function atTime(base, hh, mm) {
  const d = new Date(base);
  d.setHours(hh, mm, 0, 0);
  return d.getTime();
}

export function describe(schedule) {
  return schedule || '';
}

// 计算下次执行时间（>= after）
export function nextRun(schedule, after = Date.now()) {
  const parts = String(schedule).trim().split(/\s+/);
  const kind = parts[0];
  if (kind === 'interval') {
    const min = parseInt(parts[1], 10) || 60;
    return after + min * 60000;
  }
  if (kind === 'daily') {
    const [hh, mm] = parts[1].split(':').map(Number);
    let t = atTime(after, hh, mm);
    if (t <= after) t = atTime(after + 86400000, hh, mm);
    return t;
  }
  if (kind === 'weekly') {
    const target = WEEK.indexOf(parts[1].toUpperCase());
    const [hh, mm] = parts[2].split(':').map(Number);
    for (let i = 0; i < 8; i++) {
      const d = new Date(after + i * 86400000);
      if (d.getDay() === target) {
        let t = atTime(d, hh, mm);
        if (t > after) return t;
      }
    }
    return after + 7 * 86400000;
  }
  if (kind === 'monthly') {
    const dom = parseInt(parts[1], 10);
    const [hh, mm] = parts[2].split(':').map(Number);
    for (let i = 0; i < 40; i++) {
      const d = new Date(after + i * 86400000);
      if (d.getDate() === dom) {
        let t = atTime(d, hh, mm);
        if (t > after) return t;
      }
    }
    return after + 30 * 86400000;
  }
  if (kind === 'cron') {
    return nextCron(parts.slice(1), after);
  }
  throw new Error('未知 schedule: ' + schedule);
}

function matchField(val, field) {
  if (field === '*') return true;
  return field.split(',').some((seg) => {
    if (seg.includes('-')) {
      const [a, b] = seg.split('-').map(Number);
      return val >= a && val <= b;
    }
    return Number(seg) === val;
  });
}
function nextCron(f, after) {
  for (let i = 0; i < 1 << 20; i++) {
    const d = new Date(after + i * 60000);
    if (matchField(d.getMinutes(), f[0]) &&
        matchField(d.getHours(), f[1]) &&
        matchField(d.getDate(), f[2]) &&
        matchField(d.getMonth() + 1, f[3]) &&
        matchField(d.getDay(), f[4])) {
      const t = d.getTime();
      if (t > after) return t;
    }
  }
  return after + 365 * 86400000;
}

export class Scheduler {
  constructor() {
    this.plans = [];
    this.timer = null;
    this.tickMs = 30000;
  }
  add(plan) {
    plan.next = nextRun(plan.schedule);
    this.plans.push(plan);
    return plan;
  }
  remove(id) {
    this.plans = this.plans.filter((p) => p.id !== id);
  }
  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), this.tickMs);
  }
  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
  tick() {
    const now = Date.now();
    for (const p of this.plans) {
      if (p.next && now >= p.next) {
        const run = p.onRun;
        if (run) run(p).catch((e) => console.error('[scheduler]', p.id, e && e.message));
        p.last = p.next;
        p.next = nextRun(p.schedule, now);
      }
    }
  }
}
