// src/cli.js — 运维/演示命令行
//   node src/cli.js sample [dir]   生成示例「已解密导出目录」（供文件导入适配器端到端验证）
//   node src/cli.js serve          启动管理端（同 npm start）
import fs from 'node:fs';
import path from 'node:path';
import { createApp } from './api/server.js';

const cmd = process.argv[2] || 'serve';

if (cmd === 'sample') {
  const dir = process.argv[3] || './import';
  const mediaDir = path.join(dir, 'media');
  fs.mkdirSync(mediaDir, { recursive: true });
  // 生成一张占位图片（1x1 png）作为媒体示例
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M8AAAMBAQDJ/pLvAAAAAElFTkSuQmCC', 'base64');
  fs.writeFileSync(path.join(mediaDir, 'hello.png'), png);
  const sessions = [
    {
      id: 'wxid_friend_a', name: '好友A', type: 'friend',
      messages: [
        { id: 1, ts: Date.now() - 60000, sender: 'me', kind: 'text', text: '在吗？周末爬山不？' },
        { id: 2, ts: Date.now() - 30000, sender: 'friend', kind: 'text', text: '走起！' },
        { id: 3, ts: Date.now() - 10000, sender: 'me', kind: 'image', text: '[图片]', media: { name: 'hello.png', mime: 'image/png', file: 'hello.png' } },
      ],
    },
    {
      id: 'group_team', name: '项目群', type: 'group',
      messages: [
        { id: 1, ts: Date.now() - 120000, sender: 'bob', kind: 'text', text: '备份方案评审会 15:00' },
        { id: 2, ts: Date.now() - 90000, sender: 'me', kind: 'text', text: '收到' },
      ],
    },
  ];
  for (const s of sessions) fs.writeFileSync(path.join(dir, `${s.id}.json`), JSON.stringify(s, null, 2));
  console.log('已生成示例导出目录：', path.resolve(dir));
  console.log('会话：', sessions.map((s) => s.name).join(', '));
} else {
  const DATA_DIR = process.env.WEBACKUP_DATA_DIR || './data';
  const PORT = parseInt(process.env.PORT || '8080', 10);
  const EXPORT_DIR = process.env.WEBACKUP_EXPORT_DIR || './import';
  createApp({ dataDir: DATA_DIR, exportDir: EXPORT_DIR, port: PORT });
}
