import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from './server.js';

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), 'wb-api-')); }

test('端到端：设置→建账号→解锁→备份→校验→恢复', async () => {
  const dataDir = tmp();
  const exportDir = tmp();
  fs.writeFileSync(path.join(exportDir, 's1.json'), JSON.stringify({
    id: 's1', name: '好友A', type: 'friend',
    messages: [{ id: 1, ts: 1, sender: 'me', kind: 'text', text: 'hi' }],
  }));

  const app = createApp({ dataDir, exportDir, port: 0 });
  app.scheduler.stop();
  await new Promise((res) => (app.server.listening ? res() : app.server.once('listening', res)));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;
  const cj = [];

  async function call(method, p, body) {
    const res = await fetch(base + p, {
      method,
      headers: { 'Content-Type': 'application/json', ...(cj.length ? { Cookie: cj.join('; ') } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const sc = res.headers.get('set-cookie');
    if (sc) cj.push(sc.split(';')[0]);
    return { status: res.status, data: await res.json().catch(() => ({})) };
  }

  let r = await call('GET', '/api/status');
  assert.equal(r.data.setup, false);

  r = await call('POST', '/api/setup', { user: 'admin', password: 'Admin1234' });
  assert.equal(r.status, 200);

  r = await call('POST', '/api/accounts', { account: 'wx_a', passphrase: 'Str0ng#1', confirm: 'Str0ng#1' });
  assert.equal(r.status, 200);
  assert.ok(r.data.recoveryCode, '应返回恢复代码');

  r = await call('POST', '/api/accounts/wx_a/unlock', { secret: 'Str0ng#1' });
  assert.equal(r.status, 200);

  r = await call('POST', '/api/accounts/wx_a/backup', { kind: 'full' });
  assert.equal(r.status, 200);
  assert.ok(r.data.id);

  r = await call('GET', '/api/accounts/wx_a/snapshots');
  assert.ok(r.data.snapshots.length >= 1);
  const snapId = r.data.snapshots[0].id;

  r = await call('GET', `/api/accounts/wx_a/verify/${snapId}`);
  assert.equal(r.data.ok, true);

  const outDir = tmp();
  r = await call('POST', '/api/accounts/wx_a/restore', { snapId, outDir });
  assert.equal(r.status, 200);
  assert.ok(fs.existsSync(path.join(outDir, 's1.json')), '恢复应导出会话文件');

  // 恢复代码可解锁（无口令恢复路径）
  r = await call('POST', '/api/accounts/wx_a/lock', {});
  assert.equal(r.status, 200);
  r = await call('POST', '/api/accounts/wx_a/unlock', { secret: 'WRONG' });
  assert.equal(r.status, 401);

  app.server.close();
});

test('安装向导种子：admin.seed.json 应自动初始化管理员并自删', async () => {
  const dataDir = tmp();
  // 模拟 install_callback 写入的一次性种子（与 compose 挂载的 /data 对齐）
  fs.writeFileSync(path.join(dataDir, 'admin.seed.json'), JSON.stringify({ user: 'seedadmin', password: 'SeedPass#123' }));

  const app = createApp({ dataDir, exportDir: tmp(), port: 0 });
  app.scheduler.stop();
  await new Promise((res) => (app.server.listening ? res() : app.server.once('listening', res)));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  const st = await fetch(base + '/api/status').then((r) => r.json());
  assert.equal(st.setup, true, '种子应已自动完成初始化');
  assert.ok(fs.existsSync(path.join(dataDir, 'admin.seed.json')) === false, '种子文件应被删除');

  // 用种子账号登录成功
  const login = await fetch(base + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user: 'seedadmin', password: 'SeedPass#123' }),
  });
  assert.equal(login.status, 200, '种子管理员应能登录');
  app.server.close();
});
