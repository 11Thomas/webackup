import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from './server.js';

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), 'wb-api-')); }

async function startApp(dataDir, exportDir = tmp()) {
  const app = createApp({ dataDir, exportDir, port: 0 });
  app.scheduler.stop();
  await new Promise((res) => (app.server.listening ? res() : app.server.once('listening', res)));
  const port = app.server.address().port;
  return { app, base: `http://127.0.0.1:${port}` };
}

function client(base) {
  const cj = [];
  return async function call(method, p, body) {
    const res = await fetch(base + p, {
      method,
      headers: { 'Content-Type': 'application/json', ...(cj.length ? { Cookie: cj.join('; ') } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const sc = res.headers.get('set-cookie');
    if (sc) cj.push(sc.split(';')[0]);
    return { status: res.status, data: await res.json().catch(() => ({})) };
  };
}

test('端到端：设置→新建项目→解锁→文件备份→恢复', async () => {
  const dataDir = tmp();
  const sourceDir = tmp();
  fs.mkdirSync(path.join(sourceDir, 'docs'), { recursive: true });
  fs.writeFileSync(path.join(sourceDir, 'hello.txt'), 'Hello NAS');
  fs.writeFileSync(path.join(sourceDir, 'docs', 'note.md'), '# note');

  const { app, base } = await startApp(dataDir);
  const call = client(base);

  let r = await call('GET', '/api/status');
  assert.equal(r.data.setup, false);

  r = await call('POST', '/api/setup', { user: 'admin', password: 'Admin1234' });
  assert.equal(r.status, 200);

  r = await call('POST', '/api/projects', { name: '我的文档', source: sourceDir, passphrase: 'Str0ng#1' });
  assert.equal(r.status, 200);
  assert.ok(r.data.recoveryCode, '应返回恢复代码');
  const pid = r.data.id;

  r = await call('POST', `/api/projects/${pid}/unlock`, { secret: 'Str0ng#1' });
  assert.equal(r.status, 200);

  r = await call('POST', `/api/projects/${pid}/backup`, { kind: 'full' });
  assert.equal(r.status, 200);
  assert.ok(r.data.id);
  assert.equal(r.data.msgCount, 2);

  r = await call('GET', `/api/projects/${pid}/snapshots`);
  assert.ok(r.data.snapshots.length >= 1);
  const snapId = r.data.snapshots[0].id;

  r = await call('GET', `/api/projects/${pid}/files?snap=${snapId}`);
  assert.equal(r.status, 200);
  assert.equal(r.data.files.length, 2);

  const outDir = tmp();
  r = await call('POST', `/api/projects/${pid}/restore`, { snapId, outDir });
  assert.equal(r.status, 200);
  assert.ok(fs.existsSync(path.join(outDir, 'hello.txt')), '应恢复 hello.txt');
  assert.equal(fs.readFileSync(path.join(outDir, 'hello.txt'), 'utf8'), 'Hello NAS');

  app.server.close();
});

test('安装向导种子：admin.seed.json 应自动初始化管理员并自删', async () => {
  const dataDir = tmp();
  fs.writeFileSync(path.join(dataDir, 'admin.seed.json'), JSON.stringify({ user: 'seedadmin', password: 'SeedPass#123' }));
  const { app, base } = await startApp(dataDir);

  const st = await fetch(base + '/api/status').then((r) => r.json());
  assert.equal(st.setup, true, '种子应已自动完成初始化');
  assert.ok(fs.existsSync(path.join(dataDir, 'admin.seed.json')) === false, '种子文件应被删除');

  const login = await fetch(base + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user: 'seedadmin', password: 'SeedPass#123' }),
  });
  assert.equal(login.status, 200, '种子管理员应能登录');
  app.server.close();
});
