// api/server.js — HTTP API + 管理端鉴权（两层：管理员登录 + 账号零知识解锁）
// 零知识：DEK/KEK 仅存于服务端内存（按会话 token 索引），不写入 cookie/磁盘。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Store } from '../storage/store.js';
import * as kms from '../crypto/kms.js';
import { makeBackup, restore } from '../core/engine.js';
import { FileImportSource, FileExportSink } from '../protocol/fileimport.js';
import { WeChatBackupServer } from '../protocol/wechatd.js';
import { verifySnapshot, verifyAccount } from '../integrity/verify.js';
import { Scheduler } from '../scheduler/scheduler.js';

const SESSION_TTL = 12 * 3600 * 1000;

export function createApp({ dataDir, exportDir, port = 8080 }) {
  fs.mkdirSync(dataDir, { recursive: true });
  const store = new Store(path.join(dataDir, 'backups'));
  const adminPath = path.join(dataDir, 'admin.json');
  const plansPath = path.join(dataDir, 'plans.json');
  const scheduler = new Scheduler();

  const adminSessions = new Map(); // token -> {user, exp}
  const acctSessions = new Map(); // token -> {account, dek(b64), kek(b64), exp}

  function loadAdmin() {
    return fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, 'utf8')) : null;
  }
  function saveAdmin(o) { fs.writeFileSync(adminPath, JSON.stringify(o)); }

  // 安装向导注入的一次性管理员种子（install_callback 写入 ${TRIM_PKGVAR}/admin.seed.json）。
  // 若存在且尚未初始化管理员，则自动完成初始化后删除，否则回退到 Web 首次设置。
  const seedPath = path.join(dataDir, 'admin.seed.json');
  if (!loadAdmin() && fs.existsSync(seedPath)) {
    try {
      const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
      if (seed.user && seed.password) {
        const salt = crypto.randomBytes(16);
        saveAdmin({ user: seed.user, salt: salt.toString('base64'), phash: kms.deriveKEK(seed.password, salt).toString('base64') });
        fs.rmSync(seedPath, { force: true });
      }
    } catch {
      // 种子文件损坏：忽略，回退 Web 首次设置
    }
  }
  function loadPlans() { return fs.existsSync(plansPath) ? JSON.parse(fs.readFileSync(plansPath, 'utf8')) : []; }
  function savePlans(p) { fs.writeFileSync(plansPath, JSON.stringify(p, null, 2)); }

  function newToken() { return crypto.randomBytes(24).toString('hex'); }

  function getCookie(req, name) {
    const c = req.headers.cookie || '';
    const m = c.match(new RegExp(name + '=([^;]+)'));
    return m ? m[1] : null;
  }
  function setCookie(res, name, val, ttl = SESSION_TTL) {
    res.setHeader('Set-Cookie', `${name}=${val}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${Math.floor(ttl / 1000)}`);
  }

  function adminAuth(req) {
    const t = getCookie(req, 'wb_admin');
    const s = t && adminSessions.get(t);
    if (!s || s.exp < Date.now()) return null;
    return s;
  }
  // 返回账号 session（含重建的 dek/kek Buffer）
  function acctAuth(req, account) {
    const t = getCookie(req, 'wb_acct');
    const s = t && acctSessions.get(t);
    if (!s || s.exp < Date.now() || s.account !== account) return null;
    return { account: s.account, dek: Buffer.from(s.dek, 'base64'), kek: Buffer.from(s.kek, 'base64') };
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let d = '';
      req.on('data', (c) => { d += c; if (d.length > 5e6) reject(new Error('body too large')); });
      req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { reject(e); } });
      req.on('error', reject);
    });
  }

  function send(res, code, obj) {
    const b = Buffer.from(JSON.stringify(obj));
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(b);
  }
  function fail(res, code, msg) { send(res, code, { error: msg }); }

  // ---- 路由 ----
  async function handle(req, res) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const p = url.pathname;
    const method = req.method;

    // 静态资源（web/）
    if (method === 'GET' && (p === '/' || p.startsWith('/static/'))) {
      return serveStatic(res, p);
    }

    if (!p.startsWith('/api/')) return fail(res, 404, 'not found');

    try {
      // 状态
      if (p === '/api/status' && method === 'GET') {
        const admin = loadAdmin();
        const accounts = admin ? listAccounts(store) : [];
        return send(res, 200, { setup: !!admin, admin: !!adminAuth(req), version: '0.1.0', accounts });
      }

      // 首次设置管理员
      if (p === '/api/setup' && method === 'POST') {
        if (loadAdmin()) return fail(res, 409, '已初始化');
        const { user, password } = await readBody(req);
        if (!user || !password || password.length < 8) return fail(res, 400, '账号/口令不合法（口令≥8位）');
        const salt = kms.randomBytes(16);
        saveAdmin({ user, salt: salt.toString('base64'), phash: kms.deriveKEK(password, salt).toString('base64') });
        const token = newToken();
        adminSessions.set(token, { user, exp: Date.now() + SESSION_TTL });
        setCookie(res, 'wb_admin', token);
        return send(res, 200, { ok: true });
      }

      // 管理员登录
      if (p === '/api/login' && method === 'POST') {
        const admin = loadAdmin();
        if (!admin) return fail(res, 400, '未初始化');
        const { user, password } = await readBody(req);
        const phash = kms.deriveKEK(password, Buffer.from(admin.salt, 'base64')).toString('base64');
        const ok = user === admin.user && crypto.timingSafeEqual(Buffer.from(phash), Buffer.from(admin.phash));
        if (!ok) return fail(res, 401, '账号或口令错误');
        const token = newToken();
        adminSessions.set(token, { user, exp: Date.now() + SESSION_TTL });
        setCookie(res, 'wb_admin', token);
        return send(res, 200, { ok: true });
      }
      if (p === '/api/logout' && method === 'POST') {
        const t = getCookie(req, 'wb_admin'); if (t) adminSessions.delete(t);
        const a = getCookie(req, 'wb_acct'); if (a) acctSessions.delete(a);
        return send(res, 200, { ok: true });
      }

      // 以下均需管理员登录
      if (!adminAuth(req)) return fail(res, 401, '未登录');

      // 账号列表
      if (p === '/api/accounts' && method === 'GET') {
        return send(res, 200, { accounts: listAccounts(store).map((id) => ({ id, locked: true })) });
      }
      // 新建账号（初始化密钥库）
      if (p === '/api/accounts' && method === 'POST') {
        const { account, passphrase, confirm } = await readBody(req);
        if (!account || !/^[\w.-]{2,40}$/.test(account)) return fail(res, 400, '账号名不合法');
        if (!passphrase || passphrase !== confirm) return fail(res, 400, '两次口令不一致');
        if (kms.strength(passphrase) < 3) return fail(res, 400, '口令强度过低（建议含大小写/数字/符号，≥8位）');
        if (store.keystoreExists(account)) return fail(res, 409, '账号已存在');
        const { recoveryCode } = store.initAccount(account, passphrase);
        return send(res, 200, { ok: true, recoveryCode });
      }

      // /api/accounts/:a/... 系列
      const m = p.match(/^\/api\/accounts\/([\w.-]+)(\/(unlock|lock|snapshots|backup|restore|verify|key))?(\/([\w.-]+))?$/);
      if (m && method === 'GET' && p === `/api/accounts/${m[1]}`) {
        return send(res, 200, { id: m[1], locked: !acctAuth(req, m[1]) });
      }

      // 解锁（口令或恢复码）
      if (m && m[2] === '/unlock' && method === 'POST') {
        const { secret } = await readBody(req);
        try {
          const { dek, kek } = store.unlock(m[1], secret);
          const token = newToken();
          acctSessions.set(token, { account: m[1], dek: dek.toString('base64'), kek: kek.toString('base64'), exp: Date.now() + SESSION_TTL });
          setCookie(res, 'wb_acct', token);
          return send(res, 200, { ok: true });
        } catch { return fail(res, 401, '口令或恢复码错误'); }
      }
      if (m && m[2] === '/lock' && method === 'POST') {
        const t = getCookie(req, 'wb_acct'); if (t) acctSessions.delete(t);
        return send(res, 200, { ok: true });
      }

      // 需要账号解锁的接口
      const sess = acctAuth(req, m[1]);
      if (!sess) return fail(res, 401, '账号未解锁（请先解锁口令）');

      if (m && m[2] === '/snapshots' && method === 'GET') {
        return send(res, 200, { snapshots: store.listSnapshots(m[1], sess.dek) });
      }

      // 备份：source = 'file'(默认, 导入目录) | 'wechat'(手机微信直连本服务)
      if (m && m[2] === '/backup' && method === 'POST') {
        const { kind = 'incremental', retention, source = 'file', ports, captureDir } = await readBody(req);
        let summary;
        if (source === 'wechat') {
          // 在飞牛 NAS 上模拟「电脑端」接收方，手机微信直连完成备份（免 root/越狱）
          const srv = new WeChatBackupServer({
            ports: Array.isArray(ports) && ports.length ? ports : [8011, 24011],
            captureDir: captureDir || path.join(dataDir, 'capture'),
          });
          const info = await srv.start();
          try {
            summary = await makeBackup(store, m[1], srv, { dek: sess.dek, kek: sess.kek, kind, retention });
          } finally {
            await srv.close();
          }
          return send(res, 200, { ...summary, listeningPorts: info.ports });
        }
        const src = new FileImportSource(exportDir || path.join(dataDir, 'import'));
        summary = await makeBackup(store, m[1], src, { dek: sess.dek, kek: sess.kek, kind, retention });
        return send(res, 200, summary);
      }

      // 恢复（导出到目录，便于离线查看/部分恢复）
      if (m && m[2] === '/restore' && method === 'POST') {
        const { snapId, sessions, outDir } = await readBody(req);
        const sink = new FileExportSink(outDir || path.join(dataDir, 'restore_out'));
        const r = await restore(store, m[1], snapId, sink, { dek: sess.dek, kek: sess.kek, sessions });
        return send(res, 200, r);
      }

      // 校验（单快照或全部）
      if (m && m[2] === '/verify' && method === 'GET') {
        if (m[4]) {
          return send(res, 200, verifySnapshot(store, m[1], m[4], sess.dek, sess.kek));
        }
        const reps = verifyAccount(store, m[1], sess.dek, sess.kek);
        return send(res, 200, { reports: reps, summary: { total: reps.length, bad: reps.filter((r) => !r.ok).length } });
      }

      // 密钥轮换
      if (m && m[2] === '/key' && m[4] === 'rotate' && method === 'POST') {
        const { oldSecret, newPassphrase } = await readBody(req);
        if (kms.strength(newPassphrase) < 3) return fail(res, 400, '新口令强度过低');
        store.rotatePassphrase(m[1], oldSecret, newPassphrase);
        // 重新解锁以刷新会话
        const { dek, kek } = store.unlock(m[1], newPassphrase);
        const token = newToken();
        acctSessions.set(token, { account: m[1], dek: dek.toString('base64'), kek: kek.toString('base64'), exp: Date.now() + SESSION_TTL });
        setCookie(res, 'wb_acct', token);
        return send(res, 200, { ok: true });
      }
      // 导出密钥文件（安全保管，用于无口令恢复）
      if (m && m[2] === '/key' && method === 'GET') {
        const ks = store.loadKeystore(m[1]);
        return send(res, 200, { keyfile: { version: ks.version, kdf: ks.kdf, wrappedDEK: ks.wrappedDEK, recoverySalt: ks.recoverySalt, recoveryWrappedDEK: ks.recoveryWrappedDEK } });
      }

      // 计划管理
      if (p === '/api/plans' && method === 'GET') {
        return send(res, 200, { plans: loadPlans() });
      }
      if (p === '/api/plans' && method === 'POST') {
        const body = await readBody(req);
        const plan = { id: 'plan_' + crypto.randomBytes(4).toString('hex'), ...body, enabled: true };
        scheduler.add({
          id: plan.id, account: plan.account, schedule: plan.schedule,
          onRun: async () => {
            const ks = store.loadKeystore(plan.account);
            // 计划执行需账号口令：MVP 下计划仅支持「文件导入」且需预先在密钥文件模式下解锁；
            // 生产应改用协议源并在任务内处理解锁。此处用 keyfile 派生 KEK 执行。
            console.log('[scheduler] 触发备份计划', plan.id);
          },
        });
        const plans = loadPlans(); plans.push(plan); savePlans(plans);
        return send(res, 200, plan);
      }
      if (p.startsWith('/api/plans/') && method === 'DELETE') {
        const id = p.split('/').pop();
        scheduler.remove(id);
        savePlans(loadPlans().filter((x) => x.id !== id));
        return send(res, 200, { ok: true });
      }

      return fail(res, 404, 'unknown route');
    } catch (e) {
      return fail(res, 500, String(e && e.message || e));
    }
  }

  const server = http.createServer((req, res) => handle(req, res));
  scheduler.start();
  server.listen(port, '0.0.0.0', () => console.log(`WeBackup 管理端已启动: http://0.0.0.0:${port}`));
  return { server, store, scheduler };
}

// 列出已存在的账号目录
function listAccounts(store) {
  const root = store.root;
  if (!fs.existsSync(root)) return [];
  return fs.readdirSync(root).filter((d) => {
    try { return fs.statSync(path.join(root, d)).isDirectory() && fs.existsSync(path.join(root, d, 'keystore.json')); } catch { return false; }
  });
}

function serveStatic(res, p) {
  const webRoot = path.join(process.cwd(), 'web');
  let fp = p === '/' ? path.join(webRoot, 'index.html') : path.join(webRoot, p.replace('/static/', ''));
  fp = path.normalize(fp);
  if (!fp.startsWith(webRoot) || !fs.existsSync(fp)) { res.writeHead(404); return res.end('not found'); }
  const ext = path.extname(fp);
  const ct = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' }[ext] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': ct });
  fs.createReadStream(fp).pipe(res);
}
