// api/server.js — HTTP API + 管理端鉴权（两层：管理员登录 + 项目零知识解锁）
// 零知识：DEK/KEK 仅存于服务端内存（按会话 token 索引），不写入 cookie/磁盘。
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Store } from '../storage/store.js';
import * as kms from '../crypto/kms.js';
import { makeBackup, restore } from '../core/engine.js';
import { FileImportSource, FileExportSink } from '../protocol/fileimport.js';
import { FileBackupSource, FileTreeSink, humanSize } from '../protocol/filetree.js';
import { WeChatBackupServer } from '../protocol/wechatd.js';
import { verifySnapshot, verifyAccount } from '../integrity/verify.js';
import { Scheduler, nextRun, describe } from '../scheduler/scheduler.js';

const SESSION_TTL = 12 * 3600 * 1000;

export function createApp({ dataDir, exportDir, port = 8080 }) {
  fs.mkdirSync(dataDir, { recursive: true });
  const store = new Store(path.join(dataDir, 'backups'));
  const adminPath = path.join(dataDir, 'admin.json');
  const plansPath = path.join(dataDir, 'plans.json');
  const scheduler = new Scheduler();

  const adminSessions = new Map(); // token -> {user, exp}
  const acctSessions = new Map(); // token -> {account, dek(b64), kek(b64), exp}

  function loadAdmin() { return fs.existsSync(adminPath) ? JSON.parse(fs.readFileSync(adminPath, 'utf8')) : null; }
  function saveAdmin(o) { fs.writeFileSync(adminPath, JSON.stringify(o)); }
  function loadPlans() { return fs.existsSync(plansPath) ? JSON.parse(fs.readFileSync(plansPath, 'utf8')) : []; }
  function savePlans(p) { fs.writeFileSync(plansPath, JSON.stringify(p, null, 2)); }

  // 安装向导注入的一次性管理员种子
  const seedPath = path.join(dataDir, 'admin.seed.json');
  if (!loadAdmin() && fs.existsSync(seedPath)) {
    try {
      const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
      if (seed.user && seed.password) {
        const salt = crypto.randomBytes(16);
        saveAdmin({ user: seed.user, salt: salt.toString('base64'), phash: kms.deriveKEK(seed.password, salt).toString('base64') });
        fs.rmSync(seedPath, { force: true });
      }
    } catch { /* 忽略损坏种子 */ }
  }

  function newToken() { return crypto.randomBytes(24).toString('hex'); }
  function getCookie(req, name) {
    const c = req.headers.cookie || '';
    const m = c.match(new RegExp(name + '=([^;]+)'));
    return m ? m[1] : null;
  }
  function setCookie(res, name, val, ttl = SESSION_TTL) {
    res.setHeader('Set-Cookie', `${name}=${val}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${Math.floor(ttl / 1000)}`);
  }
  function adminAuth(req) {
    const t = getCookie(req, 'wb_admin');
    const s = t && adminSessions.get(t);
    return s && s.exp >= Date.now() ? s : null;
  }
  function acctAuth(req, account) {
    const t = getCookie(req, 'wb_acct');
    const s = t && acctSessions.get(t);
    if (!s || s.exp < Date.now() || s.account !== account) return null;
    return { account: s.account, dek: Buffer.from(s.dek, 'base64'), kek: Buffer.from(s.kek, 'base64') };
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let d = '';
      req.on('data', (c) => { d += c; if (d.length > 10 * 1024 * 1024) reject(new Error('body too large')); });
      req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { reject(e); } });
      req.on('error', reject);
    });
  }
  function send(res, code, obj) {
    const b = Buffer.from(JSON.stringify(obj));
    res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(b);
  }
  function fail(res, code, msg) { send(res, code, { error: msg }); }

  // 项目元数据
  function metaPath(id) { return path.join(store.accountDir(id), 'meta.json'); }
  function loadMeta(id) {
    const fp = metaPath(id);
    return fs.existsSync(fp) ? JSON.parse(fs.readFileSync(fp, 'utf8')) : null;
  }
  function saveMeta(id, meta) { fs.writeFileSync(metaPath(id), JSON.stringify(meta, null, 2)); }
  function projectIdFromName(name) {
    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'project';
    return `${slug}-${crypto.randomBytes(4).toString('hex')}`;
  }
  function listProjects() {
    return listAccounts(store).map((id) => {
      const meta = loadMeta(id) || { name: id, source: '' };
      const token = Array.from(acctSessions.entries()).find(([, v]) => v.account === id && v.exp > Date.now());
      const sessions = loadSnapshotsSafe(id);
      const last = sessions[sessions.length - 1];
      return {
        id, name: meta.name || id, source: meta.source || '',
        locked: !token, createdAt: meta.createdAt,
        lastSnap: last ? last.id : null, lastTime: last ? last.time : null,
        snapshotCount: sessions.length,
      };
    });
  }
  function loadSnapshotsSafe(id) {
    try {
      const t = Array.from(acctSessions.entries()).find(([, v]) => v.account === id && v.exp > Date.now());
      if (!t) return [];
      return store.listSnapshots(id, Buffer.from(t[1].dek, 'base64'));
    } catch { return []; }
  }
  function calcStats() {
    const accounts = listAccounts(store);
    let size = 0;
    for (const id of accounts) {
      const dir = store.accountDir(id);
      try {
        for (const f of fs.readdirSync(path.join(dir, 'chunks'))) {
          const s = fs.statSync(path.join(dir, 'chunks', f));
          size += s.size;
        }
        for (const f of fs.readdirSync(path.join(dir, 'snapshots'))) {
          const sdir = path.join(dir, 'snapshots', f);
          if (fs.statSync(sdir).isDirectory()) {
            if (fs.existsSync(path.join(sdir, 'manifest.bin'))) size += fs.statSync(path.join(sdir, 'manifest.bin')).size;
          }
        }
      } catch {}
    }
    let lastTime = 0;
    for (const p of listProjects()) {
      if (p.lastTime && p.lastTime > lastTime) lastTime = p.lastTime;
    }
    return { projects: accounts.length, snapshots: accounts.reduce((a, id) => a + loadSnapshotsSafe(id).length, 0), sizeBytes: size, lastTime: lastTime || null };
  }

  // 统一的计划执行逻辑
  async function runPlan(p) {
    const sessEntry = Array.from(acctSessions.entries()).find(([, v]) => v.account === p.account && v.exp > Date.now());
    if (!sessEntry) {
      console.log('[scheduler] 项目未解锁，跳过计划', p.id);
      updatePlanStatus(p.id, { status: 'skipped', reason: '项目未解锁' });
      return;
    }
    const s = sessEntry[1];
    const meta = loadMeta(p.account);
    try {
      await runBackup(p.account, Buffer.from(s.dek, 'base64'), Buffer.from(s.kek, 'base64'), p.kind || 'incremental', meta?.source, meta?.retention);
      updatePlanStatus(p.id, { status: 'ok', lastRun: Date.now() });
    } catch (e) {
      console.error('[scheduler] 计划失败', p.id, e.message);
      updatePlanStatus(p.id, { status: 'failed', reason: e.message, lastRun: Date.now() });
    }
  }

  // 加载并启动计划
  function loadAndStartPlans() {
    for (const plan of loadPlans()) {
      if (!plan.enabled) continue;
      scheduler.add({
        id: plan.id,
        account: plan.account,
        schedule: plan.schedule,
        kind: plan.kind || 'incremental',
        next: nextRun(plan.schedule),
        onRun: runPlan,
      });
    }
  }
  function updatePlanStatus(id, patch) {
    const plans = loadPlans();
    const idx = plans.findIndex((x) => x.id === id);
    if (idx >= 0) {
      plans[idx] = { ...plans[idx], ...patch };
      savePlans(plans);
    }
  }

  async function runBackup(account, dek, kek, kind, sourceDir, retention) {
    let lastManifest = null;
    if (kind === 'incremental') {
      const idx = store.readIndex(account, dek);
      if (idx.snapshots.length) {
        const parent = idx.snapshots[idx.snapshots.length - 1].id;
        try { lastManifest = store.readManifest(account, parent, dek, kek); } catch {}
      }
    }
    const src = new FileBackupSource(sourceDir || path.join(dataDir, 'import'), { incremental: kind === 'incremental', lastManifest });
    const summary = await makeBackup(store, account, src, { dek, kek, kind, retention });
    return summary;
  }

  async function handle(req, res) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const p = url.pathname;
    const method = req.method;

    if (method === 'GET' && (p === '/' || p.startsWith('/static/'))) return serveStatic(res, p);
    if (!p.startsWith('/api/')) return fail(res, 404, 'not found');

    try {
      // 状态
      if (p === '/api/status' && method === 'GET') {
        const admin = loadAdmin();
        return send(res, 200, { setup: !!admin, admin: !!adminAuth(req), version: '0.1.1', stats: admin ? calcStats() : null });
      }

      if (p === '/api/setup' && method === 'POST') {
        if (loadAdmin()) return fail(res, 409, '已初始化');
        const { user, password } = await readBody(req);
        if (!user || !password || password.length < 8) return fail(res, 400, '账号/口令不合法');
        const salt = kms.randomBytes(16);
        saveAdmin({ user, salt: salt.toString('base64'), phash: kms.deriveKEK(password, salt).toString('base64') });
        const token = newToken();
        adminSessions.set(token, { user, exp: Date.now() + SESSION_TTL });
        setCookie(res, 'wb_admin', token);
        return send(res, 200, { ok: true });
      }

      if (p === '/api/login' && method === 'POST') {
        const admin = loadAdmin();
        if (!admin) return fail(res, 400, '未初始化');
        const { user, password } = await readBody(req);
        const phash = kms.deriveKEK(password, Buffer.from(admin.salt, 'base64')).toString('base64');
        const ok = user === admin.user && crypto.timingSafeEqual(Buffer.from(phash), Buffer.from(admin.phash));
        if (!ok) return fail(res, 401, '账号或口令错误');
        const token = newToken();
        adminSessions.set(token, { user, exp: Date.now() + SESSION_TTL });
        setCookie(res, 'wb_admin', token);
        return send(res, 200, { ok: true });
      }
      if (p === '/api/logout' && method === 'POST') {
        const t = getCookie(req, 'wb_admin'); if (t) adminSessions.delete(t);
        const a = getCookie(req, 'wb_acct'); if (a) acctSessions.delete(a);
        return send(res, 200, { ok: true });
      }

      if (!adminAuth(req)) return fail(res, 401, '未登录');

      // 管理员改密
      if (p === '/api/admin/pass' && method === 'POST') {
        const admin = loadAdmin();
        const { oldPassword, newPassword } = await readBody(req);
        const oldHash = kms.deriveKEK(oldPassword, Buffer.from(admin.salt, 'base64')).toString('base64');
        if (!crypto.timingSafeEqual(Buffer.from(oldHash), Buffer.from(admin.phash))) return fail(res, 401, '当前口令错误');
        if (!newPassword || newPassword.length < 8) return fail(res, 400, '新口令需≥8位');
        const salt = kms.randomBytes(16);
        saveAdmin({ user: admin.user, salt: salt.toString('base64'), phash: kms.deriveKEK(newPassword, salt).toString('base64') });
        return send(res, 200, { ok: true });
      }

      // 项目 CRUD
      if (p === '/api/projects' && method === 'GET') return send(res, 200, { projects: listProjects() });
      if (p === '/api/projects' && method === 'POST') {
        const { name, source, passphrase, schedule, retention } = await readBody(req);
        if (!name || !source || !passphrase) return fail(res, 400, '名称/源路径/口令必填');
        if (passphrase.length < 8) return fail(res, 400, '口令需≥8位');
        const id = projectIdFromName(name);
        const { recoveryCode } = store.initAccount(id, passphrase);
        saveMeta(id, { name, source, retention: retention || { keepCount: 10 }, createdAt: Date.now() });
        // 如果创建时带计划，自动添加
        if (schedule) {
          const plan = { id: 'plan_' + crypto.randomBytes(4).toString('hex'), account: id, schedule, kind: 'incremental', enabled: true };
          plan.next = nextRun(plan.schedule);
          scheduler.add({ ...plan, onRun: runPlan });
          const plans = loadPlans(); plans.push(plan); savePlans(plans);
        }
        return send(res, 200, { id, recoveryCode });
      }
      if (p === '/api/projects' && method === 'DELETE') {
        const { id } = await readBody(req);
        if (!store.keystoreExists(id)) return fail(res, 404, '项目不存在');
        fs.rmSync(store.accountDir(id), { recursive: true, force: true });
        scheduler.plans = scheduler.plans.filter((x) => x.account !== id);
        savePlans(loadPlans().filter((x) => x.account !== id));
        return send(res, 200, { ok: true });
      }

      // 项目级路由匹配
      const m = p.match(/^\/api\/projects\/([a-zA-Z0-9_.\-]+)(\/([a-zA-Z0-9_.\-]+))?$/);
      if (m && method === 'GET' && !m[2]) {
        const meta = loadMeta(m[1]) || {};
        return send(res, 200, { id: m[1], name: meta.name, source: meta.source, locked: !acctAuth(req, m[1]) });
      }

      if (m && m[3] === 'unlock' && method === 'POST') {
        const { secret } = await readBody(req);
        try {
          const { dek, kek } = store.unlock(m[1], secret);
          const token = newToken();
          acctSessions.set(token, { account: m[1], dek: dek.toString('base64'), kek: kek.toString('base64'), exp: Date.now() + SESSION_TTL });
          setCookie(res, 'wb_acct', token);
          return send(res, 200, { ok: true });
        } catch { return fail(res, 401, '口令或恢复码错误'); }
      }
      if (m && m[3] === 'lock' && method === 'POST') {
        const t = getCookie(req, 'wb_acct'); if (t) acctSessions.delete(t);
        return send(res, 200, { ok: true });
      }
      if (m && m[3] === 'snapshots' && method === 'GET') {
        const sess = acctAuth(req, m[1]);
        if (!sess) return fail(res, 401, '项目未解锁');
        return send(res, 200, { snapshots: store.listSnapshots(m[1], sess.dek) });
      }
      if (m && m[3] === 'backup' && method === 'POST') {
        const sess = acctAuth(req, m[1]);
        if (!sess) return fail(res, 401, '项目未解锁');
        const { kind = 'incremental' } = await readBody(req);
        const meta = loadMeta(m[1]) || {};
        const summary = await runBackup(m[1], sess.dek, sess.kek, kind, meta.source, meta.retention);
        return send(res, 200, summary);
      }
      if (m && m[3] === 'restore' && method === 'POST') {
        const sess = acctAuth(req, m[1]);
        if (!sess) return fail(res, 401, '项目未解锁');
        const { snapId, outDir } = await readBody(req);
        const sink = new FileTreeSink(outDir || path.join(dataDir, 'restore_out'));
        const r = await restore(store, m[1], snapId, sink, { dek: sess.dek, kek: sess.kek });
        return send(res, 200, r);
      }
      if (m && m[3] === 'files' && method === 'GET') {
        const sess = acctAuth(req, m[1]);
        if (!sess) return fail(res, 401, '项目未解锁');
        const snapId = url.searchParams.get('snap');
        if (!snapId) return fail(res, 400, '缺少 snap 参数');
        const manifest = store.readManifest(m[1], snapId, sess.dek, sess.kek);
        const files = [];
        for (const meta of manifest.sessions) {
          const parts = [];
          for (const ref of meta.chunkRefs) parts.push(store.readChunk(m[1], ref.hash, sess.dek));
          const session = JSON.parse(Buffer.concat(parts).toString('utf8'));
          files.push({ id: meta.id, name: meta.name, type: meta.type || session.type, size: meta.size || 0, mtime: meta.mtime || 0 });
        }
        return send(res, 200, { files });
      }

      // 计划管理 /api/schedules
      if (p === '/api/schedules' && method === 'GET') {
        const plans = loadPlans();
        return send(res, 200, { schedules: plans.map((x) => ({ ...x, nextAt: x.next || null })) });
      }
      if (p === '/api/schedules' && method === 'POST') {
        const body = await readBody(req);
        if (!body.project || !body.schedule) return fail(res, 400, '项目和 schedule 必填');
        const plan = { id: 'plan_' + crypto.randomBytes(4).toString('hex'), account: body.project, schedule: body.schedule, kind: body.kind || 'incremental', enabled: body.enabled !== false };
        plan.next = nextRun(plan.schedule);
        scheduler.add({
          id: plan.id, account: plan.account, schedule: plan.schedule, kind: plan.kind, next: plan.next,
          onRun: runPlan,
        });
        const plans = loadPlans(); plans.push(plan); savePlans(plans);
        return send(res, 200, plan);
      }
      if (p.startsWith('/api/schedules/') && method === 'DELETE') {
        const id = p.split('/').pop();
        scheduler.remove(id);
        savePlans(loadPlans().filter((x) => x.id !== id));
        return send(res, 200, { ok: true });
      }

      return fail(res, 404, 'unknown route');
    } catch (e) {
      console.error('[api]', e);
      return fail(res, 500, String(e && e.message || e));
    }
  }

  const server = http.createServer((req, res) => handle(req, res));
  loadAndStartPlans();
  scheduler.start();
  server.listen(port, '0.0.0.0', () => console.log(`WeBackup 管理端已启动: http://0.0.0.0:${port}`));
  return { server, store, scheduler };
}

function listAccounts(store) {
  const root = store.root;
  if (!fs.existsSync(root)) return [];
  return fs.readdirSync(root).filter((d) => {
    try { return fs.statSync(path.join(root, d)).isDirectory() && fs.existsSync(path.join(root, d, 'keystore.json')); } catch { return false; }
  });
}

function serveStatic(res, p) {
  const webRoot = path.join(process.cwd(), 'web');
  let fp = p === '/' ? path.join(webRoot, 'index.html') : path.join(webRoot, p.replace('/static/', ''));
  fp = path.normalize(fp);
  if (!fp.startsWith(webRoot) || !fs.existsSync(fp)) { res.writeHead(404); return res.end('not found'); }
  const ext = path.extname(fp);
  const ct = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' }[ext] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': ct });
  fs.createReadStream(fp).pipe(res);
}
