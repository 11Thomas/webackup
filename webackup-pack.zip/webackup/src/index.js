// src/index.js — 进程入口：启动管理端（协议服务为可插拔，本期接文件导入适配器）
import { createApp } from './api/server.js';

const DATA_DIR = process.env.WEBACKUP_DATA_DIR || './data';
const PORT = parseInt(process.env.PORT || '8099', 10);
const EXPORT_DIR = process.env.WEBACKUP_EXPORT_DIR || './import';

createApp({ dataDir: DATA_DIR, exportDir: EXPORT_DIR, port: PORT });
