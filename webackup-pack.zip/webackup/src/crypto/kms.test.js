import test from 'node:test';
import assert from 'node:assert/strict';
import * as kms from './kms.js';

test('encrypt/decrypt 往返一致（含中文/二进制）', () => {
  const key = kms.genDEK();
  const plain = Buffer.from('hello wechat backup 微信聊天记录备份 🔒', 'utf8');
  const enc = kms.encryptBuf(plain, key);
  const dec = kms.decryptBuf(enc, key);
  assert.equal(dec.toString('utf8'), plain.toString('utf8'));
});

test('错误密钥解密应失败（认证加密防篡改）', () => {
  const enc = kms.encryptBuf(Buffer.from('secret-data'), kms.genDEK());
  assert.throws(() => kms.decryptBuf(enc, kms.genDEK()));
});

test('KEK 派生确定性 + DEK 包裹/解包', () => {
  const salt = kms.randomBytes(16);
  const kek = kms.deriveKEK('Passw0rd!', salt);
  const kek2 = kms.deriveKEK('Passw0rd!', salt);
  assert.equal(kek.toString('hex'), kek2.toString('hex'));
  const dek = kms.genDEK();
  const w = kms.wrapDEK(dek, kek);
  assert.ok(kms.unwrapDEK(w, kek).equals(dek));
  assert.throws(() => kms.unwrapDEK(w, kms.deriveKEK('wrong-pass', salt)));
});

test('恢复代码可解包 DEK（无口令恢复路径）', () => {
  const code = kms.genRecoveryCode();
  const salt = kms.randomBytes(16);
  const kek = kms.deriveKEK(kms.recoveryCodeToBytes(code), salt);
  const dek = kms.genDEK();
  const w = kms.wrapDEK(dek, kek);
  assert.ok(kms.unwrapDEK(w, kek).equals(dek));
});

test('口令强度评分', () => {
  assert.equal(kms.strength(''), 0);
  assert.ok(kms.strength('Abcd123!@#x') >= 4);
  assert.ok(kms.strength('abc') <= 1);
});
