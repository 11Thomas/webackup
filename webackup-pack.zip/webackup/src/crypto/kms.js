// crypto/kms.js — 安全内核：KDF、信封加密、块加密、HMAC、恢复代码、密钥文件
// 纯 Node 标准库实现（node:crypto），零外部依赖，便于离线构建与审计。
import crypto from 'node:crypto';

// KDF 参数（内存硬，抗 GPU/ASIC 暴力）。生产可升级为 Argon2id。
const KDF_DEFAULTS = { N: 1 << 15, r: 8, p: 1, keylen: 32 };
export const NONCE_LEN = 12;
export const TAG_LEN = 16;

export function randomBytes(n) {
  return crypto.randomBytes(n);
}

// 口令/恢复码 -> 密钥加密密钥 KEK
export function deriveKEK(secret, salt, opts = {}) {
  const { N, r, p, keylen, maxmem } = { ...KDF_DEFAULTS, ...opts };
  const buf = Buffer.isBuffer(secret) ? secret : Buffer.from(String(secret), 'utf8');
  // maxmem 需 >= 128*N*r；默认给 64MiB 余量（生产可调高以抗暴力）
  return crypto.scryptSync(buf, salt, keylen, { N, r, p, maxmem: maxmem || 64 * 1024 * 1024 });
}

// 数据加密密钥 DEK（每账号/快照随机）
export function genDEK() {
  return crypto.randomBytes(32);
}

// AES-256-GCM 加密一个 Buffer，返回 {nonce, tag, ct}（均为 Buffer）
export function encryptBuf(plain, key) {
  const nonce = crypto.randomBytes(NONCE_LEN);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, nonce, { authTagLength: TAG_LEN });
  const ct = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { nonce, tag, ct };
}

// 解密 {nonce, tag, ct}，认证失败抛错（防篡改）
export function decryptBuf(blob, key) {
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, blob.nonce, { authTagLength: TAG_LEN });
  decipher.setAuthTag(blob.tag);
  return Buffer.concat([decipher.update(blob.ct), decipher.final()]);
}

// 磁盘块格式：nonce(12) + tag(16) + ciphertext
export function serializeBlob({ nonce, tag, ct }) {
  return Buffer.concat([nonce, tag, ct]);
}
export function parseBlob(buf) {
  return {
    nonce: buf.subarray(0, NONCE_LEN),
    tag: buf.subarray(NONCE_LEN, NONCE_LEN + TAG_LEN),
    ct: buf.subarray(NONCE_LEN + TAG_LEN),
  };
}

// 用 KEK 包裹/解包 DEK（信封加密）
export function wrapDEK(dek, kek) {
  return encryptBuf(dek, kek);
}
export function unwrapDEK(wrapped, kek) {
  return decryptBuf(wrapped, kek);
}

// 清单防篡改签名
export function hmacSHA256(data, key) {
  return crypto.createHmac('sha256', key).update(data).digest();
}

export function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

// 恢复代码：20 随机字节 -> Base32 分组（用于无口令恢复 DEK）
export function genRecoveryCode() {
  const b = crypto.randomBytes(20);
  return base32(b).match(/.{1,4}/g).join('-').toUpperCase();
}
export function recoveryCodeToBytes(code) {
  return base32decode(String(code).replace(/[- ]/g, '').toUpperCase());
}

// 口令强度 0-5
export function strength(pwd) {
  let s = 0;
  if (typeof pwd !== 'string' || pwd.length === 0) return 0;
  if (pwd.length >= 8) s++;
  if (pwd.length >= 12) s++;
  if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) s++;
  if (/\d/.test(pwd)) s++;
  if (/[^A-Za-z0-9]/.test(pwd)) s++;
  return Math.min(s, 5);
}

// ---- Base32 (RFC4648) 工具 ----
function base32(buf) {
  const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0, value = 0, out = '';
  for (const b of buf) {
    value = (value << 8) | b; bits += 8;
    while (bits >= 5) { out += a[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += a[(value << (5 - bits)) & 31];
  return out;
}
function base32decode(str) {
  const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const map = {};
  a.split('').forEach((c, i) => { map[c] = i; });
  let bits = 0, value = 0, out = [];
  for (const c of str) {
    if (c in map) {
      value = (value << 5) | map[c]; bits += 5;
      while (bits >= 8) { out.push((value >>> (bits - 8)) & 0xff); bits -= 8; }
    }
  }
  return Buffer.from(out);
}
