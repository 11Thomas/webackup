// protocol/wechatd.test.js — 微信备份格式库 + WeChatBackupServer 端到端测试
import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  generateSessionKey, segmentKey16, encryptSegment, decryptSegment,
  encodeMessage, decodeMessage, decryptBackupDb, deriveSqlcipherKey, scanTable, buildSyntheticBackup,
} from './wechat-format.js';
import { WeChatBackupServer, WeChatEmulationClient, WeChatRestoreSink } from './wechatd.js';
import { Store } from '../storage/store.js';
import { makeBackup } from '../core/engine.js';

const MSG = {
  type: 1, sender: 'wxid_alice', receiver: 'wxid_bob',
  content: '嗯嗯，我刚才去看了也不在[破涕为笑]', createTime: 1720602127,
  msgSvrId: 739315802669645222n, msgSequence: 852963701, sequenceMs: 1720602127000n,
};

test('片段 AES-ECB(前16字节密钥) 加解密 round-trip', () => {
  const key = generateSessionKey();
  const k16 = segmentKey16(key);
  const plain = Buffer.from('微信聊天记录片段-PKCS7-填充对齐测试-1234567890', 'utf8');
  const ct = encryptSegment(plain, k16);
  assert.equal(ct.length % 16, 0);
  assert.notEqual(ct.toString('hex'), plain.toString('hex'));
  assert.deepEqual(decryptSegment(ct, k16), plain);
});

test('protobuf 消息编解码 + 字段映射（含 64 位 msgSvrId 不丢精度）', () => {
  const proto = encodeMessage(MSG);
  const m = decodeMessage(proto);
  assert.equal(m.sender, 'wxid_alice');
  assert.equal(m.receiver, 'wxid_bob');
  assert.equal(m.content, MSG.content);
  assert.equal(m.createTime, 1720602127);
  assert.equal(m.msgSvrId, '739315802669645222'); // 字符串化，无精度损失
  assert.equal(m.sequenceMs, 1720602127000);
});

test('decryptBackupDb：SQLCipher3 单页解密 round-trip', () => {
  const key32 = generateSessionKey();
  const PAGE = 4096, RES = 48;
  const salt = crypto.randomBytes(16);
  const { key } = deriveSqlcipherKey(key32, salt); // 加密侧用派生密钥，与解密端一致
  const data = Buffer.alloc(PAGE - RES); // 4048 字节明文数据（恰为 16 的倍数）
  const IV = crypto.randomBytes(16);
  const tail = Buffer.concat([IV, Buffer.alloc(32)]); // 48 字节保留（IV+HMAC+reserved）
  const plainPage = Buffer.concat([data, tail]);
  // SQLCipher 页加密：AES-256-CBC 无填充（setAutoPadding(false)）；密文在前、保留(含IV)在后
  const cipher = crypto.createCipheriv('aes-256-cbc', key, IV);
  cipher.setAutoPadding(false);
  const ct = Buffer.concat([cipher.update(data), cipher.final()]);
  const file = Buffer.concat([salt, ct, tail]);
  const out = decryptBackupDb(file, key32);
  assert.equal(out.length, PAGE);
  assert.deepEqual(out, plainPage);
});

test('scanTable：最小 SQLite leaf 页解析（text/int 列）', () => {
  const PAGE = 4096;
  const page = Buffer.alloc(PAGE);
  page[0] = 0x0d; // leaf table b-tree
  page.writeUInt16BE(0, 1); // freeblock
  page.writeUInt16BE(2, 3); // num cells
  page.writeUInt16BE(0, 5); // cell content start
  // 造两条记录
  const mkRow = (conv, name, n) => {
    const rec = Buffer.concat([
      Buffer.from([4]), // header len
      Buffer.from([23, 23, 1]), // 两个 text(len5) + int1
      Buffer.from(conv), Buffer.from(name), Buffer.from([n]),
    ]);
    const payload = Buffer.concat([Buffer.from([rec.length]), Buffer.from([n]), rec]);
    return payload;
  };
  const a = mkRow('conv1', 'Alice', 1);
  const b = mkRow('conv2', 'Bob', 2);
  // 放在页尾
  a.copy(page, PAGE - a.length - b.length);
  b.copy(page, PAGE - b.length);
  page.writeUInt16BE(PAGE - a.length - b.length, 8);
  page.writeUInt16BE(PAGE - b.length, 10);
  const rows = scanTable(2, PAGE, (pg) => (pg === 2 ? page : Buffer.alloc(0)));
  assert.equal(rows.length, 2);
  assert.equal(rows[0].cols[0], 'conv1');
  assert.equal(rows[0].cols[1], 'Alice');
  assert.equal(rows[0].cols[2], 1);
  assert.equal(rows[1].cols[0], 'conv2');
});

test('WeChatBackupServer：TCP 端到端（模拟手机端直连备份）', async () => {
  const key = generateSessionKey();
  const srv = new WeChatBackupServer({ ports: [0], sessionKey: key });
  const info = await srv.start();
  const port = info.ports[0];

  const cli = new WeChatEmulationClient(key);
  await cli.connect(port);
  cli.sendSegment('wxid_bob', 'Bob', 'friend', MSG);
  cli.sendSegment('wxid_bob', 'Bob', 'friend', { type: 1, sender: 'wxid_bob', receiver: 'wxid_alice', content: '收到~', createTime: 1720602200, msgSvrId: 739315802669645223n });
  cli.endConversation('wxid_bob');
  await new Promise((r) => setTimeout(r, 60));
  cli.close();
  await srv.close();

  const sessions = [];
  for await (const s of srv.sessions()) sessions.push(s);
  assert.equal(sessions.length, 1);
  assert.equal(sessions[0].id, 'wxid_bob');
  assert.equal(sessions[0].messages.length, 2);
  assert.equal(sessions[0].messages[0].text, MSG.content);
  assert.equal(sessions[0].messages[0].sender, 'wxid_alice');
});

test('合成备份片段 -> 服务端 pushSegment 解码', () => {
  const key = generateSessionKey();
  const srv = new WeChatBackupServer({ sessionKey: key });
  const segs = buildSyntheticBackup([MSG, { type: 1, sender: 'wxid_bob', receiver: 'wxid_alice', content: 'hi', createTime: 1720602300, msgSvrId: 739315802669645224n }], key);
  segs.forEach((s) => srv.pushSegment('convX', 'ConvX', 'friend', s.cipher));
  srv.endFile('convX');
  assert.equal(srv._queue.length, 1);
  assert.equal(srv._queue[0].messages.length, 2);
  assert.equal(srv._queue[0].messages[1].text, 'hi');
});

test('replayCapture：回放抓包原始字节还原会话', () => {
  const key = generateSessionKey();
  const srv = new WeChatBackupServer({ sessionKey: key });
  const cli = new WeChatEmulationClient(key);
  // 直接构造帧字节（不需要真 socket）
  const hello = Buffer.from(JSON.stringify({ device: 'c', verifyCode: '' }));
  const seg = (() => {
    const cipher = encryptSegment(encodeMessage(MSG), segmentKey16(key));
    const hdr = Buffer.from(JSON.stringify({ convId: 'wxid_bob', name: 'Bob', type: 'friend' }));
    const payload = Buffer.concat([Buffer.from([4 >>> 24 & 0, 4 >>> 16 & 0, 4 >>> 8 & 0, hdr.length]), hdr, cipher]);
    return Buffer.concat([Buffer.from([0x03]), uint32(payload.length), payload]);
  })();
  const end = Buffer.from(JSON.stringify({ convId: 'wxid_bob' }));
  const endFrame = Buffer.concat([Buffer.from([0x04]), uint32(end.length), end]);
  const raw = Buffer.concat([Buffer.concat([Buffer.from([0x01]), uint32(hello.length), hello]), seg, endFrame]);
  const out = WeChatBackupServer.replayCapture(raw, key);
  assert.equal(out.length, 1);
  assert.equal(out[0].messages[0].text, MSG.content);
});

test('WeChatRestoreSink：同一会话密钥重加密片段', () => {
  const key = generateSessionKey();
  const sink = new WeChatRestoreSink(key);
  const session = { id: 'wxid_bob', name: 'Bob', type: 'friend', messages: [{ sender: 'wxid_alice', text: '回放消息', ts: 1720602127 }] };
  const run = async () => { await sink.begin(); await sink.writeSession(session); await sink.end(); };
  return run().then(() => {
    const segs = sink.toSegments();
    assert.equal(segs.length, 1);
    // 重加密片段应能反向解密还原
    const plain = decryptSegment(segs[0], segmentKey16(key));
    const m = decodeMessage(plain);
    assert.equal(m.content, '回放消息');
  });
});

function uint32(n) { const b = Buffer.alloc(4); b.writeUInt32BE(n >>> 0, 0); return b; }

test('端到端：手机直连备份 -> 引擎端到端加密存储', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'wb-e2e-'));
  const store = new Store(path.join(tmp, 'data'));
  const account = 'wxid_bob';
  const { dek, kek } = store.initAccount(account, 'Passw0rd!Strong');
  const srv = new WeChatBackupServer({ ports: [0], sessionKey: generateSessionKey() });
  const info = await srv.start();
  const cli = new WeChatEmulationClient(srv.sessionKey);
  await cli.connect(info.ports[0]);
  cli.sendSegment(account, 'Bob', 'friend', MSG);
  cli.sendSegment('wxid_alice', 'Alice', 'friend', { type: 1, sender: 'wxid_alice', receiver: account, content: '你好', createTime: 1720603000, msgSvrId: 739315802669645225n });
  cli.endConversation(account);
  cli.endConversation('wxid_alice');
  await new Promise((r) => setTimeout(r, 80));
  cli.close();
  await srv.close(); // 置 _done，使 sessions() 在产出后正常结束
  const res = await makeBackup(store, account, srv, { dek, kek, kind: 'full' });
  assert.ok(res.id);
  assert.equal(res.msgCount, 2);
  const manifest = store.readManifest(account, res.id, dek, kek);
  assert.equal(manifest.sessions.length, 2);
  fs.rmSync(tmp, { recursive: true, force: true });
});
