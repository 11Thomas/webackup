// protocol/filetree.js — 通用文件/目录备份源与恢复目标
// 将任意文件夹作为备份源，每个文件视为一个独立会话，便于增量与按路径恢复。
// 注意：MVP 把文件内容 base64 后嵌入消息 media.data；大文件场景建议后续改用分块引用。
import fs from 'node:fs';
import path from 'node:path';
import { BackupSource, RestoreSink } from './types.js';

function mimeFromName(name) {
  const ext = path.extname(name).toLowerCase();
  const map = {
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
    '.webp': 'image/webp', '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.mp3': 'audio/mpeg',
    '.pdf': 'application/pdf', '.txt': 'text/plain', '.md': 'text/markdown', '.json': 'application/json',
    '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.zip': 'application/zip',
  };
  return map[ext] || 'application/octet-stream';
}

function humanSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return (n / 1024 / 1024 / 1024).toFixed(1) + ' GB';
}

export class FileBackupSource extends BackupSource {
  constructor(sourceDir, { incremental = false, lastManifest = null } = {}) {
    super();
    this.dir = path.resolve(sourceDir);
    this.lastManifest = lastManifest;
    if (this.lastManifest) {
      const lastFiles = {};
      for (const meta of this.lastManifest.sessions || []) {
        if (meta.type === 'file') {
          lastFiles[meta.id] = meta.mtime || 0;
        }
      }
      this.lastFiles = lastFiles;
    } else {
      this.lastFiles = {};
    }
  }

  async *sessions() {
    if (!fs.existsSync(this.dir)) {
      throw new Error('备份源目录不存在：' + this.dir);
    }
    const base = this.dir;
    const walk = (dir) => {
      const entries = [];
      for (const name of fs.readdirSync(dir)) {
        if (name.startsWith('.')) continue;
        const full = path.join(dir, name);
        const rel = path.relative(base, full).replace(/\\/g, '/');
        const stat = fs.statSync(full);
        if (stat.isDirectory()) {
          entries.push({ id: rel, name, type: 'dir', mtime: stat.mtimeMs, size: 0 });
          entries.push(...walk(full));
        } else if (stat.isFile()) {
          entries.push({ id: rel, name, type: 'file', mtime: stat.mtimeMs, size: stat.size });
        }
      }
      return entries;
    };

    const files = walk(base);
    for (const f of files) {
      if (f.type === 'dir') {
        // 目录由文件路径隐式重建，不再单独作为会话，减少冗余
        continue;
      } else {
        // 增量：跳过 mtime 未变且上次已存在的文件
        if (this.lastFiles[f.id] && this.lastFiles[f.id] >= f.mtime) continue;
        const buf = fs.readFileSync(path.join(base, f.id));
        const data = buf.toString('base64');
        yield {
          id: f.id,
          name: f.name,
          type: 'file',
          mtime: f.mtime,
          size: f.size,
          messages: [{
            id: 'file',
            ts: f.mtime,
            sender: '',
            kind: 'file',
            text: f.id,
            media: { name: f.name, mime: mimeFromName(f.name), data, size: f.size },
          }],
        };
      }
    }
  }
}

export class FileTreeSink extends RestoreSink {
  constructor(outDir) {
    super();
    this.dir = path.resolve(outDir);
  }

  async begin() {
    fs.mkdirSync(this.dir, { recursive: true });
  }

  async writeSession(session) {
    const target = path.join(this.dir, session.id);
    if (session.type === 'dir') {
      fs.mkdirSync(target, { recursive: true });
      return;
    }
    const msg = (session.messages || [])[0];
    if (msg && msg.media && msg.media.data) {
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, Buffer.from(msg.media.data, 'base64'));
    }
  }

  async end() {}
}

export { humanSize };
