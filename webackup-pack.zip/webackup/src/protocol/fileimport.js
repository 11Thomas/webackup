// protocol/fileimport.js — 文件导入适配器（BackupSource）
// 读取「已解密的导出目录」：每个会话一个 <sessionId>.json，媒体在 media/ 下按文件名引用。
// 这是无需真机抓包即可端到端验证全链路的可用数据源；也对应「桌面代理导入」回退路线。
import fs from 'node:fs';
import path from 'node:path';
import { BackupSource } from './types.js';

export class FileImportSource extends BackupSource {
  constructor(exportDir) {
    super();
    this.dir = exportDir;
  }

  async *sessions() {
    const files = fs.readdirSync(this.dir).filter((f) => f.endsWith('.json'));
    for (const f of files) {
      const raw = JSON.parse(fs.readFileSync(path.join(this.dir, f), 'utf8'));
      const session = {
        id: raw.id,
        name: raw.name,
        type: raw.type || 'friend',
        messages: (raw.messages || []).map((m) => this._resolveMedia(m)),
      };
      yield session;
    }
  }

  _resolveMedia(m) {
    if (m.media && m.media.file) {
      const fp = path.join(this.dir, 'media', m.media.file);
      if (fs.existsSync(fp)) {
        const data = fs.readFileSync(fp).toString('base64');
        return { ...m, media: { name: m.media.name || m.media.file, mime: m.media.mime || 'application/octet-stream', data } };
      }
    }
    return m;
  }
}

// 反向：把会话导出为文件（RestoreSink），便于「离线查看 / 部分恢复导出」
import { RestoreSink } from './types.js';

export class FileExportSink extends RestoreSink {
  constructor(outDir) {
    super();
    this.dir = outDir;
    this.mediaDir = path.join(outDir, 'media');
  }
  async begin() {
    fs.mkdirSync(this.mediaDir, { recursive: true });
  }
  async writeSession(session) {
    const out = {
      id: session.id,
      name: session.name,
      type: session.type,
      messages: (session.messages || []).map((m) => {
        if (m.media && m.media.data && !m.media.file) {
          const fn = `${session.id}_${m.id || Date.now()}`;
          fs.writeFileSync(path.join(this.mediaDir, fn), Buffer.from(m.media.data, 'base64'));
          return { ...m, media: { ...m.media, file: fn } };
        }
        return m;
      }),
    };
    fs.writeFileSync(path.join(this.dir, `${session.id}.json`), JSON.stringify(out, null, 2));
  }
}
