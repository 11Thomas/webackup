# 微信官方备份协议 — 已确认事实与抓包攻坚台（Harness）

本文件汇总「微信 3.x 备份与迁移 / 备份聊天记录到电脑」协议的**已公开逆向事实**
（来源：52pojie《解开Windows微信备份文件》xuxinhang 2025-04；WxBackup 商业版端口信息；
WeChatDataAnalysis / chatlog 等开源解密方案），并给出在 NAS 端补全 `WeChatBackupServer` 的路线。

> ⚠️ 微信 **4.0** 已重写备份格式（源码与磁盘格式均变化），本工程针对 **3.x**。
> 活体握手（设备发现 / 验证码确认 / 密钥协商字节流）仍未公开，见文末「待抓包补全」。

---

## 1. 已确认的磁盘格式（手机→电脑备份的产物）

备份目录形如 `WeChat Files\<wxid>\BackupFiles\<时间戳>\`，含三类文件：

| 文件 | 内容 | 加密 |
|------|------|------|
| `Backup.db` | SQLCipher3 加密 SQLite；`Session` 表存会话名，`MsgSegments`/`MsgMedia`/`MsgFileSegments` 表存片段的 `文件名/偏移/长度` | AES-256-CBC + PBKDF2-HMAC-SHA1(迭代 **64000**, salt=文件前 16 字节)；`mac_salt = salt XOR 0x3a`；页大小 4096，每页保留 48 字节(16 IV + 20 HMAC + 12) |
| `BAK_0_TEXT` | 文本消息片段（多段拼接） | 每个片段 **AES-ECB**，密钥取 32 字节会话密钥的 **前 16 字节**，PKCS7 填充 |
| `BAK_0_MEDIA` / `BAK_1_MEDIA` | 图片/视频/语音等媒体片段 | 同上（AES-ECB，前 16 字节密钥）；长文件分多段，仅末段需去填充 |

关键事实：
- **会话密钥 32 字节，由「电脑端」生成并下发给手机**（日志 `DEBUG: backup db: encryptkey[...] from server`）。
  手机用其前 16 字节做片段 AES-ECB；用完整 32 字节做 `Backup.db` 的 SQLCipher 密钥。
- 每个 `BAK_*` 片段**相互独立可解密**（解密单元 = 一条消息或一个媒体片段），由 `MsgSegments` 等表的 `offset/length` 定位。
- 片段解密后是 **protobuf**；消息字段号（逆向结果）见 `wechat-format.js` 的 `MESSAGE_FIELDS`：
  - `1`=类型, `3.1`=发送者wxid, `4.1`=接收者wxid, `5.1`=文本内容, `7`=CreateTime(秒),
    `16`=MsgSvrId(64位,字符串化), `17`=MsgSequence, `18`=SequenceMs(毫秒), `11`=媒体信息。

---

## 2. 本工程已补全的部分（`wechat-format.js` + `wechatd.js`）

纯 Node 标准库、零外部依赖、可离线构建与审计，且**已用单测验证**：

1. **会话密钥**：`generateSessionKey()`（32 字节）；`segmentKey16()` 取前 16 字节。
2. **片段加/解密**：`encryptSegment` / `decryptSegment`（AES-128-ECB，PKCS7）——与微信一致。
3. **protubuf 编/解码**：`encodeMessage` / `decodeMessage` 按上表字段映射；64 位 `MsgSvrId` 字符串化不丢精度。
4. **Backup.db 解密**：`decryptBackupDb()` 实现 SQLCipher3 页解密（AES-256-CBC 无填充；数据在前、48 字节保留含 IV 在后）。并附最小 SQLite b-tree 读取 `readBackupDbTables()`（支持 `Session`/`MsgSegments` 等表）。
5. **导入已有备份**：`loadBackupFromDisk(dir, key32)` —— 解密 `Backup.db` 拿片段位置，读 `BAK_*` 片段用前 16 字节密钥解密、解码 protobuf，还原会话（离线查看已有 Windows 微信备份）。
6. **接收服务** `WeChatBackupServer`（继承 `BackupSource`）：
   - TCP 监听（默认 `8011`/`24011`，即微信官方端口）。
   - 握手：收到手机 `HELLO` 后下发 32 字节会话密钥（对应 "encryptkey from server"）。
     **⚠️ 此处为 emulation 契约**：真实微信的设备发现/验证码协商字节流为私有，抓到后只需替换 `handshakeState()` 中的私有字节，片段解密与消息解析无需改动。
   - 传输：按文档片段格式接收 → AES-ECB 解密 → protobuf 解码 → `sessions()` 产出 `{id,name,type,messages}`。
   - 抓包：`captureDir` 非空时记录每个连接的原始字节，供回放验证。
   - 回放：`WeChatBackupServer.replayCapture(rawBuf, key)` 把记录字节喂入解码管线。
7. **反向通道** `WeChatRestoreSink`：用同一会话密钥把会话重加密为微信片段（真实推回手机的网络层为私有恢复协议，待抓包补全）。

---

## 3. 端到端验证（无需真机）

`src/protocol/wechatd.test.js`（9 个用例，全部通过）：
- 片段 AES-ECB round-trip；protobuf 字段映射（含 64 位 MsgSvrId）；
- `decryptBackupDb` SQLCipher3 单页 round-trip；最小 SQLite leaf 页解析；
- **TCP 端到端**：`WeChatEmulationClient` 模拟手机直连 → 服务端解码出消息；
- `replayCapture` 回放；`WeChatRestoreSink` 重加密；
- **引擎端到端**：手机直连备份 → `engine.makeBackup` → 内容寻址加密块落盘。

---

## 4. 真机抓包补全路线（P2 攻坚）

1. **抓包环境**：Windows/macOS 装官方微信桌面版；手机与 NAS 同 Wi-Fi。
   Wireshark 过滤 TCP `tcp.port in {8011,24011,9014,20360..20367}`；或手机端抓包（小黄鸟）。
   本服务开启 `captureDir` 也会在 NAS 侧落原始字节，二者对照。
2. **复现**：电脑/NAS 微信「备份与恢复 → 备份聊天记录到电脑」；手机「备份到电脑」勾选会话。
3. **需补齐的私有字节**：
   - 设备发现 / 广播方式（手机如何枚举到本服务）；
   - 验证码/确认交互（手机端显示的确认码如何产生与校验）；
   - 密钥协商帧（本 emulation 直接下发 32 字节密钥；真实微信可能有额外的协商/加密信封）；
   - 增量游标字段（时间戳 / 本地 MsgSvrId 游标）与「部分恢复」指令。
4. **落点**：把上述字节填入 `WeChatBackupServer._handleFrame` 的 `HANDSHAKE` 分支；
   片段密码学（AES-ECB 前 16 字节、protobuf）与消息解析**无需改动**，直接复用。

---

## 5. 风险与回退

- 微信版本升级可能改协议 → 保留「协议版本配置」，便于快速适配 3.x / 4.x 不同路径。
- 若某版本握手被封锁：启用 `FileImportSource`（桌面代理导入解密后的导出目录）作为回退，
  备份/恢复链路仍可用（见 `fileimport.js`）。

## 6. 合规提示

模拟官方协议可能触及微信服务条款；定位为「个人数据备份工具」，仅处理本人数据、不破解账号，
上线前做法律自评。
