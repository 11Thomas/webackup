// protocol/types.js — 备份源 / 恢复目标 接口定义
//
// BackupSource：yield 出每个会话（好友/群）的结构化记录。
//   会话格式：{ id, name, type:'friend'|'group', messages:[{id, ts, sender, kind, text, media?}] }
//   media 可选：{ name, mime, data } 其中 data 为 base64 字符串（MVP）；生产应改为独立加密 blob。
//
// RestoreSink：接收解密后的会话，写回目标（手机/导出目录）。
//   writeSession(session) 推送一个会话。

export class BackupSource {
  // eslint-disable-next-line require-yield
  async *sessions() {
    throw new Error('BackupSource.sessions 未实现');
  }
}

export class RestoreSink {
  async begin() {}
  async writeSession(/* session */) {
    throw new Error('RestoreSink.writeSession 未实现');
  }
  async end() {}
}
