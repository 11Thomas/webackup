// protocol/wechatd.js — 微信官方「备份聊天记录到电脑」协议接收服务（补全版）
//
// 角色：在飞牛 NAS 上模拟「电脑端」备份接收方，手机微信直连本服务完成备份（免 root/越狱）。
//
// 已补全（基于公开逆向，纯标准库、可离线测试）：
//   - 会话密钥生成与下发（"encryptkey from server"，32 字节，前 16 字节用于片段 AES-ECB）
//   - 传输阶段：按微信 3.x 片段格式接收 -> AES-ECB 解密 -> protobuf 解码 -> 结构化会话
//   - 抓包记录（capture）与回放（replay）支撑真机逆向
//   - 反向通道 WeChatRestoreSink：用同一会话密钥重加密片段（真实推回手机的网络层为私有协议，已标注）
//
// ⚠️ 私有协议缺口：真机活体握手（设备发现/验证码确认/密钥协商字节流）尚未公开，本服务在
//    传输层之上以 *emulation 传输契约* 暴露同一个已被逆向确认的片段密码学。抓到真机握手后，
//    只需替换 handshakeState() 中的私有字节，片段解密与消息解析无需改动（见 capture-harness.md）。

import net from 'node:net';
import fs from 'node:fs';
import path from 'node:path';
import { BackupSource, RestoreSink } from './types.js';
import {
  generateSessionKey, segmentKey16, decryptSegment, decryptBackupDb,
  decodeMessage, normalizeMessage, encryptSegment, encodeMessage,
} from './wechat-format.js';

// emulation 传输契约帧： [type:1][len:4 BE][payload:len]
const FRAME = {
  HELLO: 0x01, // 客户端 -> 服务端：{device, verifyCode}
  KEY: 0x02, // 服务端 -> 客户端：32 字节会话密钥（"encryptkey from server"）
  SEGMENT: 0x03, // 客户端 -> 服务端：JSON头{convId,name,type} + uint32密文长 + 密文
  ENDFILE: 0x04, // 客户端 -> 服务端：JSON{convId} 结束一个会话
  BYE: 0xff,
};

export class WeChatBackupServer extends BackupSource {
  constructor(opts = {}) {
    super();
    this.ports = opts.ports || [8011, 24011];
    this.captureDir = opts.captureDir || null; // 非空则记录每个连接原始字节（抓包）
    this.sessionKey = opts.sessionKey || generateSessionKey();
    this.key16 = segmentKey16(this.sessionKey);
    this.servers = [];
    this._convs = new Map(); // convId -> {id,name,type,messages:[]}
    this._queue = []; // 已完成会话
    this._waiters = [];
    this._seq = 0;
  }

  // ---- 会话产出（BackupSource 接口）----
  async *sessions() {
    for (;;) {
      if (this._queue.length) { yield this._queue.shift(); continue; }
      if (this._done && this._queue.length === 0) break;
      await new Promise((res) => this._waiters.push(res));
    }
  }
  _enqueue(session) {
    this._queue.push(session);
    while (this._waiters.length) this._waiters.shift()();
  }

  // 片段摄入（传输层与 TCP 层共用）。每个片段解密后为 *一条* 微信消息 protobuf。
  pushSegment(convId, name, type, cipherBuf) {
    if (!this._convs.has(convId)) {
      this._convs.set(convId, { id: convId, name: name || convId, type: type || 'friend', messages: [] });
    }
    const conv = this._convs.get(convId);
    if (name) conv.name = name;
    if (type) conv.type = type;
    const plain = decryptSegment(cipherBuf, this.key16); // AES-ECB, 前16字节密钥
    const msg = decodeMessage(plain); // protobuf
    conv.messages.push(normalizeMessage(msg));
    return conv;
  }
  endFile(convId) {
    const conv = this._convs.get(convId);
    if (!conv) return;
    this._convs.delete(convId);
    this._enqueue({
      id: conv.id, name: conv.name, type: conv.type,
      messages: conv.messages,
    });
  }

  // ---- TCP 监听（模拟电脑端接收方）----
  async start() {
    for (const port of this.ports) {
      const server = net.createServer((sock) => this._onConnection(sock, port));
      await new Promise((res, rej) => {
        server.once('error', rej);
        server.listen(port, () => { server.removeListener('error', rej); res(); });
      });
      this.servers.push(server);
    }
    return { ports: this.servers.map((s) => s.address().port), sessionKey: this.sessionKey };
  }
  async close() {
    this._done = true;
    await Promise.all(this.servers.map((s) => new Promise((r) => s.close(r))));
    this.servers = [];
    while (this._waiters.length) this._waiters.shift()();
  }

  _onConnection(sock, port) {
    const caps = this.captureDir ? this._openCapture(port) : null;
    const conn = { sock, buf: Buffer.alloc(0), state: 'HANDSHAKE', caps };
    sock.on('data', (d) => {
      if (caps) caps.stream.write(d);
      conn.buf = Buffer.concat([conn.buf, d]);
      try { this._pump(conn); } catch (e) { sock.destroy(); }
    });
    sock.on('close', () => { if (caps) caps.stream.end(); });
    // 握手：等待客户端 HELLO，随后下发会话密钥（真实微信此处为私有验证码协商）
    // 注：真实协议的设备发现/验证码由微信客户端发起，本 emulation 在收到 HELLO 后直接下发 KEY。
  }

  _pump(conn) {
    for (;;) {
      if (conn.buf.length < 5) return;
      const type = conn.buf[0];
      const len = conn.buf.readUInt32BE(1);
      if (conn.buf.length < 5 + len) return;
      const payload = conn.buf.subarray(5, 5 + len);
      conn.buf = conn.buf.subarray(5 + len);
      this._handleFrame(conn, type, payload);
    }
  }

  _handleFrame(conn, type, payload) {
    switch (type) {
      case FRAME.HELLO: {
        // === 私有协议缺口：此处应校验设备/验证码 ===
        // emulation：直接回发会话密钥
        conn.sock.write(Buffer.concat([Buffer.from([FRAME.KEY]), uint32(this.sessionKey.length), this.sessionKey]));
        conn.state = 'TRANSFER';
        break;
      }
      case FRAME.SEGMENT: {
        const hdrLen = payload.readUInt32BE(0);
        const hdr = JSON.parse(payload.subarray(4, 4 + hdrLen).toString('utf8'));
        const cipher = payload.subarray(4 + hdrLen);
        this.pushSegment(hdr.convId, hdr.name, hdr.type, cipher);
        break;
      }
      case FRAME.ENDFILE: {
        const hdr = JSON.parse(payload.toString('utf8'));
        this.endFile(hdr.convId);
        break;
      }
      case FRAME.BYE:
        // 手机端结束备份（真实微信对应传输完成）→ 终止会话产出
        this._done = true;
        while (this._waiters.length) this._waiters.shift()();
        conn.sock.end();
        break;
      case FRAME.KEY: // 不应由客户端发来
      default:
        break;
    }
  }

  _openCapture(port) {
    try {
      fs.mkdirSync(this.captureDir, { recursive: true });
      const fp = path.join(this.captureDir, `capture_${Date.now()}_${port}.raw`);
      return { stream: fs.createWriteStream(fp) };
    } catch {
      return null;
    }
  }

  // ---- 抓包回放：把记录的原始会话字节喂入解码管线做验证 ----
  static replayCapture(rawBuf, sessionKey) {
    const srv = new WeChatBackupServer({ sessionKey });
    let off = 0;
    while (off + 5 <= rawBuf.length) {
      const type = rawBuf[off];
      const len = rawBuf.readUInt32BE(off + 1);
      if (off + 5 + len > rawBuf.length) break;
      const payload = rawBuf.subarray(off + 5, off + 5 + len);
      off += 5 + len;
      if (type === FRAME.SEGMENT) {
        const hdrLen = payload.readUInt32BE(0);
        const hdr = JSON.parse(payload.subarray(4, 4 + hdrLen).toString('utf8'));
        srv.pushSegment(hdr.convId, hdr.name, hdr.type, payload.subarray(4 + hdrLen));
      } else if (type === FRAME.ENDFILE) {
        const hdr = JSON.parse(payload.toString('utf8'));
        srv.endFile(hdr.convId);
      }
    }
    return srv._queue;
  }
}

function uint32(n) { const b = Buffer.alloc(4); b.writeUInt32BE(n, 0); return b; }

// ---- 桌面代理/测试用：模拟手机端按 emulation 契约发送 ----
export class WeChatEmulationClient {
  constructor(sessionKey) { this.sessionKey = sessionKey; this.key16 = segmentKey16(sessionKey); }
  connect(port, host = '127.0.0.1') {
    this.sock = net.connect(port, host);
    return new Promise((res, rej) => {
      this.sock.once('error', rej);
      this.sock.once('connect', () => {
        this.sock.removeListener('error', rej);
        // 发 HELLO
        const hello = Buffer.from(JSON.stringify({ device: 'webackup-emu', verifyCode: '' }));
        this.sock.write(Buffer.concat([Buffer.from([FRAME.HELLO]), uint32(hello.length), hello]));
        // 等待服务端 KEY（emulation 下应为本端已知密钥）
        this.sock.once('data', (d) => res());
      });
    });
  }
  sendSegment(convId, name, type, message) {
    const cipher = encryptSegment(encodeMessage(message), this.key16);
    const hdr = Buffer.from(JSON.stringify({ convId, name, type }));
    const head = Buffer.concat([uint32(hdr.length), hdr]);
    const payload = Buffer.concat([head, cipher]);
    this.sock.write(Buffer.concat([Buffer.from([FRAME.SEGMENT]), uint32(payload.length), payload]));
  }
  endConversation(convId) {
    const body = Buffer.from(JSON.stringify({ convId }));
    this.sock.write(Buffer.concat([Buffer.from([FRAME.ENDFILE]), uint32(body.length), body]));
  }
  close() {
    if (this.sock) {
      try { this.sock.write(Buffer.from([FRAME.BYE])); } catch {}
      this.sock.end();
    }
  }
}

// ---- 反向通道：把会话重新加密为微信片段（恢复用）----
// 真实推回手机的网络层为微信私有恢复协议（未在公开资料中），此处完成「用同一会话密钥重加密」部分，
// 网络发送待抓包补全。
export class WeChatRestoreSink extends RestoreSink {
  constructor(sessionKey) {
    super();
    this.sessionKey = sessionKey;
    this.key16 = segmentKey16(sessionKey);
    this.segments = [];
  }
  async writeSession(session) {
    for (const m of (session.messages || [])) {
      const proto = encodeMessage({
        type: 1, sender: m.sender, receiver: session.id,
        content: m.text, createTime: m.ts,
      });
      // 每个消息 = 一个 AES-ECB 加密片段（与备份侧一致）
      this.segments.push(encryptSegment(proto, this.key16));
    }
  }
  // 返回重加密后的片段字节数组（供真实恢复协议发送）
  toSegments() { return this.segments; }
}

// 便捷：从已解密 Backup.db 字节直接做 SQLCipher 解密（供外部调用）
export { decryptBackupDb };
