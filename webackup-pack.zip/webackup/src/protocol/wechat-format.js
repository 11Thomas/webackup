// protocol/wechat-format.js — 微信 3.x「备份与迁移 / 备份聊天记录到电脑」备份格式解码库
//
// 依据公开逆向资料（52pojie《解开Windows微信备份文件》xuxinhang, 2025-04；WxBackup 商业版端口信息）
// 实现，纯 Node 标准库、零外部依赖、可离线构建与审计。
//
// 已确认的关键事实：
//   1) 会话密钥 32 字节，由「电脑端」(本应用/NAS) 生成并下发给手机（日志 "encryptkey[..] from server"）。
//   2) BAK_0_TEXT / BAK_0_MEDIA 由「独立加密片段」拼接而成，每个片段用 AES-ECB 加密，
//      密钥取 32 字节会话密钥的【前 16 字节】。长文件分多段，仅末段需去 PKCS7 填充。
//   3) 片段解密后内容是 protobuf；消息字段号来自逆向（见 MESSAGE_FIELDS）。
//   4) Backup.db 为 SQLCipher3 加密 SQLite：AES-256-CBC, PBKDF2-HMAC-SHA1(迭代 64000, salt=文件前16字节),
//      mac_salt = salt ^ 0x3a, 页大小 4096, 每页保留 48 字节(16 IV + 20 HMAC + 12)。
//      片段偏移/长度在表 MsgSegments/MsgMedia/MsgFileSegments；会话名在 Session 表。
//
// 注意：微信 4.0 已重写备份格式，本库针对 3.x。真机活体握手字节仍未公开，见 capture-harness.md。

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const SESSION_KEY_LEN = 32;
export const SEGMENT_BLOCK = 16; // AES 块大小
export const SQLCIPHER_PAGE = 4096;
export const SQLCIPHER_RESERVE = 48; // 16 IV + 20 HMAC + 12

// 微信消息 protobuf 字段映射（逆向结果，字段号 -> 含义）
export const MESSAGE_FIELDS = {
  1: 'type', // 消息类型
  3: 'sender', // {1: wxid} 发送者
  4: 'receiver', // {1: wxid} 接收者
  5: 'content', // {1: 文本} 消息内容
  6: 'subType',
  7: 'createTime', // Unix 秒
  10: 'unknownA',
  11: 'media', // 媒体文件信息（若有）
  13: 'unknownB',
  14: 'unknownC',
  15: 'unknownD',
  16: 'msgSvrId', // 消息服务端 ID（64 位，字符串化避免精度丢失）
  17: 'msgSequence',
  18: 'sequenceMs', // 毫秒时间戳
  19: 'unknownE',
};

// 消息类型 -> 资源种类（供 BackupSource 统一字段 kind）
export function kindOf(type) {
  switch (type) {
    case 1: return 'text';
    case 3: return 'image';
    case 34: return 'voice';
    case 43: return 'video';
    case 47: return 'emoji';
    case 49: return 'link'; // 分享/链接/小程序/文件等
    case 10000: return 'system';
    default: return 'unknown';
  }
}

// ---- 会话密钥 ----
export function generateSessionKey() {
  return crypto.randomBytes(SESSION_KEY_LEN);
}
// 微信仅用 32 字节密钥的前 16 字节做片段 AES-ECB
export function segmentKey16(key32) {
  if (key32.length < 16) throw new Error('会话密钥长度不足');
  return key32.subarray(0, 16);
}

// ---- AES-ECB 片段加/解密（PKCS7）----
export function encryptSegment(plain, key16) {
  const pad = SEGMENT_BLOCK - (plain.length % SEGMENT_BLOCK);
  const padded = Buffer.concat([plain, Buffer.alloc(pad, pad)]);
  const c = crypto.createCipheriv('aes-128-ecb', key16, null);
  return Buffer.concat([c.update(padded), c.final()]);
}
export function decryptSegment(cipher, key16) {
  const d = crypto.createDecipheriv('aes-128-ecb', key16, null);
  const plain = Buffer.concat([d.update(cipher), d.final()]);
  const pad = plain[plain.length - 1];
  if (pad < 1 || pad > SEGMENT_BLOCK) throw new Error('AES-ECB 填充非法');
  return plain.subarray(0, plain.length - pad);
}

// ---- 最小 protobuf 编解码 ----
function readVarint(buf, pos) {
  let shift = 0n;
  let result = 0n;
  for (;;) {
    const b = buf[pos++];
    result |= BigInt(b & 0x7f) << BigInt(shift);
    if (!(b & 0x80)) break;
    shift += 7n;
  }
  return { value: result, pos };
}
// 解析一段 protobuf -> { map: field->[values], order:[field,...] }
// 长度分隔(wire=2)的值保留为 Buffer（供嵌套再解析）
export function parseFields(buf, start = 0, end = buf.length) {
  const map = new Map();
  const order = [];
  let pos = start;
  while (pos < end) {
    const tag = readVarint(buf, pos);
    pos = tag.pos;
    const field = Number(tag.value >> 3n);
    const wire = Number(tag.value & 7n);
    let val;
    if (wire === 0) {
      const r = readVarint(buf, pos); val = r.value; pos = r.pos;
    } else if (wire === 2) {
      const r = readVarint(buf, pos); const len = Number(r.value);
      val = buf.subarray(r.pos, r.pos + len); pos = r.pos + len;
    } else if (wire === 1) {
      val = buf.subarray(pos, pos + 8); pos += 8;
    } else if (wire === 5) {
      val = buf.subarray(pos, pos + 4); pos += 4;
    } else {
      throw new Error('不支持的 protobuf wire 类型: ' + wire);
    }
    if (!map.has(field)) map.set(field, []);
    map.get(field).push(val);
    order.push(field);
  }
  return { map, order, pos };
}
function firstStr(map, field) {
  const arr = map.get(field);
  if (!arr || !arr.length) return undefined;
  const v = arr[0];
  if (Buffer.isBuffer(v)) return v.toString('utf8');
  if (typeof v === 'bigint') return v.toString();
  return String(v);
}
function innerStr(buf) {
  if (!Buffer.isBuffer(buf)) return undefined;
  const { map } = parseFields(buf, 0, buf.length);
  return firstStr(map, 1);
}
export function decodeMessage(protoBytes) {
  const { map } = parseFields(protoBytes, 0, protoBytes.length);
  const num = (f) => { const a = map.get(f); return a && a.length ? Number(a[0]) : undefined; };
  const str = (f) => { const a = map.get(f); return a && a.length ? innerStr(a[0]) : undefined; };
  const media = map.has(11) ? { raw: map.get(11)[0].toString('base64') } : undefined;
  return {
    type: num(1),
    sender: str(3),
    receiver: str(4),
    content: str(5),
    createTime: num(7),
    msgSvrId: map.has(16) ? map.get(16)[0].toString() : undefined,
    msgSequence: num(17),
    sequenceMs: num(18),
    media,
  };
}

// 合成消息（用于测试与「桌面代理」模拟手机端发送）
function encVarint(n) {
  let v = BigInt(n);
  if (v < 0n) v = v & ((1n << 64n) - 1n);
  const out = [];
  do {
    let b = Number(v & 0x7fn); v >>= 7n;
    if (v > 0n) b |= 0x80;
    out.push(b);
  } while (v > 0n);
  return Buffer.from(out);
}
function encTag(field, wire) { return encVarint((field << 3) | wire); }
function encBytes(field, buf) { return Buffer.concat([encTag(field, 2), encVarint(buf.length), buf]); }
function encStr(field, s) { return encBytes(field, Buffer.from(s, 'utf8')); }
function encVarintField(field, n) { return Buffer.concat([encTag(field, 0), encVarint(n)]); }
function encInner(field, innerField, val) { return encBytes(field, encStr(innerField, val)); }
export function encodeMessage(m) {
  const parts = [];
  if (m.type != null) parts.push(encVarintField(1, m.type));
  if (m.sender) parts.push(encInner(3, 1, m.sender));
  if (m.receiver) parts.push(encInner(4, 1, m.receiver));
  if (m.content != null) parts.push(encInner(5, 1, m.content));
  if (m.createTime != null) parts.push(encVarintField(7, m.createTime));
  if (m.msgSvrId != null) parts.push(encVarintField(16, m.msgSvrId));
  if (m.msgSequence != null) parts.push(encVarintField(17, m.msgSequence));
  if (m.sequenceMs != null) parts.push(encVarintField(18, m.sequenceMs));
  if (m.media) {
    const inner = encStr(1, m.media.name || '');
    parts.push(encBytes(11, inner));
  }
  return Buffer.concat(parts);
}

// ---- Backup.db (SQLCipher3) 解密 ----
export function deriveSqlcipherKey(password, salt) {
  const key = crypto.pbkdf2Sync(password, salt, 64000, 32, 'sha1');
  const macSalt = Buffer.from(salt.map((b) => b ^ 0x3a));
  const macKey = crypto.pbkdf2Sync(key, macSalt, 2, 32, 'sha1');
  return { key, macKey };
}
function decryptPage(ct, key) {
  const IV = ct.subarray(SQLCIPHER_PAGE - SQLCIPHER_RESERVE, SQLCIPHER_PAGE - SQLCIPHER_RESERVE + 16);
  const data = ct.subarray(0, SQLCIPHER_PAGE - SQLCIPHER_RESERVE);
  const tail = ct.subarray(SQLCIPHER_PAGE - SQLCIPHER_RESERVE);
  // SQLCipher 页加密：AES-256-CBC，无填充（固定 4048 字节数据）
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, IV);
  decipher.setAutoPadding(false);
  const ptData = Buffer.concat([decipher.update(data), decipher.final()]);
  return Buffer.concat([ptData, tail]);
}
// cipher: 加密的 Backup.db 字节；key32: 32 字节会话密钥
// 返回：解密后的明文 SQLite 文件字节（"SQLite format 3\0" 开头）
export function decryptBackupDb(cipher, key32) {
  if (cipher.length < 16 + SQLCIPHER_PAGE) throw new Error('Backup.db 过小');
  const salt = cipher.subarray(0, 16);
  const { key } = deriveSqlcipherKey(key32, salt);
  const out = Buffer.alloc(cipher.length - 16);
  let outPos = 0;
  for (let pOff = 16; pOff + SQLCIPHER_PAGE <= cipher.length; pOff += SQLCIPHER_PAGE) {
    const ct = cipher.subarray(pOff, pOff + SQLCIPHER_PAGE);
    const pt = decryptPage(ct, key);
    pt.copy(out, outPos); outPos += pt.length;
  }
  return out;
}

// ---- 最小 SQLite 读取（leaf/内部表 b-tree；支持 text/int/blob 列）----
function be16(buf, off) { return (buf[off] << 8) | buf[off + 1]; }
function be32(buf, off) { return (buf[off] * 0x1000000) + (buf[off + 1] << 16) + (buf[off + 2] << 8) + buf[off + 3]; }
// 解析一条记录字节 -> 列值数组
export function decodeRecord(rec) {
  const { value: hdrLen, pos: p0 } = readVarint(rec, 0);
  let pos = p0;
  const serials = [];
  while (pos < hdrLen) {
    const r = readVarint(rec, pos); serials.push(Number(r.value)); pos = r.pos;
  }
  const cols = [];
  for (const st of serials) {
    if (st === 0) { cols.push(null); }
    else if (st >= 1 && st <= 4) { const n = st; cols.push(Number(readVarint(rec, pos).value)); pos += n; }
    else if (st === 5) { cols.push(Number(readVarint(rec, pos).value)); pos += 6; }
    else if (st === 6) { cols.push(Number(readVarint(rec, pos).value)); pos += 8; }
    else if (st === 7) { cols.push(Number(readVarint(rec, pos).value)); pos += 8; }
    else if (st === 8) { cols.push(rec.readDoubleLE(pos)); pos += 8; }
    else if (st === 9) { cols.push(rec.readFloatLE(pos)); pos += 4; }
    else if (st >= 12 && st % 2 === 0) { const n = (st - 12) / 2; cols.push(rec.subarray(pos, pos + n)); pos += n; }
    else if (st >= 13 && st % 2 === 1) { const n = (st - 13) / 2; cols.push(rec.subarray(pos, pos + n).toString('utf8')); pos += n; }
    else { cols.push(undefined); }
  }
  return cols;
}
// 扫描一个表 b-tree 根页，返回行（列值数组）。pageFn 取页字节。
export function scanTable(rootPage, pageSize, pageFn) {
  const rows = [];
  const stack = [rootPage];
  while (stack.length) {
    const pg = stack.pop();
    const buf = pageFn(pg);
    const type = buf[0];
    if (type === 0x0d) {
      const n = be16(buf, 3);
      for (let i = 0; i < n; i++) {
        const cellOff = be16(buf, 8 + i * 2);
        const plen = readVarint(buf, cellOff); // 负载(记录)长度
        const rid = readVarint(buf, plen.pos); // rowid
        const cols = decodeRecord(buf.subarray(rid.pos, rid.pos + Number(plen.value)));
        rows.push({ rowid: Number(rid.value), cols });
      }
    } else if (type === 0x05) {
      const n = be16(buf, 3);
      for (let i = 0; i < n; i++) {
        const cellOff = be16(buf, 8 + i * 2);
        const r = readVarint(buf, cellOff);
        stack.push(be32(buf, r.pos)); // 左孩子
      }
      stack.push(be32(buf, 8)); // 最右孩子
    } else {
      // 非 b-tree 页（不应出现于此路径）
    }
  }
  return rows;
}
// 从解密后的 Backup.db 读取指定表列（columns: 列名数组）。返回 {columns, rows:[{...}]}
export function readBackupDbTables(dbBuf, tables) {
  if (dbBuf.subarray(0, 15).toString('latin1') !== 'SQLite format 3') {
    throw new Error('不是有效的 SQLite 文件');
  }
  let pageSize = be16(dbBuf, 16);
  if (pageSize === 1) pageSize = 65536;
  const pageFn = (pg) => dbBuf.subarray((pg - 1) * pageSize, pg * pageSize);
  // 解析 sqlite_schema（根页 = page 1 中的 b-tree；小库时 schema 本身在 page 1）
  const schemaRows = scanTable(1, pageSize, pageFn)
    .map((r) => ({ type: r.cols[0], name: r.cols[1], tblName: r.cols[2], rootpage: r.cols[3] }))
    .filter((r) => r.type === 'table' && tables.includes(r.name));
  const result = {};
  for (const t of schemaRows) {
    const rows = scanTable(Number(t.rootpage), pageSize, pageFn).map((r) => {
      const obj = {};
      r.cols.forEach((c, i) => { obj[i] = c instanceof Buffer ? c.toString('base64') : c; });
      return obj;
    });
    result[t.name] = rows;
  }
  return result;
}

// ---- 导入已存在的 Windows 微信备份目录（离线查看已有备份）----
// backupDir: 含 Backup.db + BAK_0_TEXT / BAK_0_MEDIA / BAK_1_MEDIA ...
// key32: 32 字节会话密钥
export function loadBackupFromDisk(backupDir, key32) {
  const dbCipher = fs.readFileSync(path.join(backupDir, 'Backup.db'));
  const db = decryptBackupDb(dbCipher, key32);
  const tables = readBackupDbTables(db, ['Session', 'MsgSegments', 'MsgMedia', 'MsgFileSegments']);
  const key16 = segmentKey16(key32);

  // 会话名：Session 表（列含义按微信：列含会话标识与显示名）
  const sessions = new Map();
  for (const row of (tables.Session || [])) {
    const id = row[0];
    const name = row[1] != null ? String(row[1]) : String(row[0]);
    sessions.set(String(id), { id: String(id), name, type: 'friend', messages: [] });
  }

  // 片段：MsgSegments(文本)/MsgMedia+MsgFileSegments(媒体) 给出 文件/偏移/长度
  const segTables = [...(tables.MsgSegments || []), ...(tables.MsgMedia || []), ...(tables.MsgFileSegments || [])];
  for (const seg of segTables) {
    // 列顺序随版本变化，按字符串/数值容错取：第1列文件名、第2列偏移、第3列长度
    const fileName = String(seg[0]);
    const offset = Number(seg[1]);
    const length = Number(seg[2]);
    if (!fileName || !Number.isFinite(offset) || !Number.isFinite(length)) continue;
    const fp = path.join(backupDir, fileName);
    if (!fs.existsSync(fp)) continue;
    const fd = fs.openSync(fp, 'r');
    const buf = Buffer.alloc(length);
    fs.readSync(fd, buf, 0, length, offset);
    fs.closeSync(fd);
    const plain = decryptSegment(buf, key16);
    const isText = fileName.startsWith('BAK_0_TEXT');
    if (isText) {
      // 文本片段 -> 一条消息，归到对应会话（无会话时建占位）
      const msg = decodeMessage(plain);
      const convId = msg.receiver || msg.sender || 'unknown';
      if (!sessions.has(convId)) sessions.set(convId, { id: convId, name: convId, type: 'friend', messages: [] });
      sessions.get(convId).messages.push(normalizeMessage(msg));
    }
    // 媒体片段：真实文件名由 MediaId 关联，需进一步映射；此处仅解密，不展开
  }
  return Array.from(sessions.values());
}

// 把 decodeMessage 结果规整为 BackupSource 会话消息格式
export function normalizeMessage(m) {
  return {
    id: m.msgSvrId || String(m.sequenceMs || ''),
    ts: m.createTime,
    sender: m.sender,
    kind: kindOf(m.type),
    text: m.content,
    media: m.media ? { name: m.media.name, raw: m.media.raw } : undefined,
  };
}

// ---- 合成备份会话（模拟手机端推送，用于端到端测试 / 桌面代理）----
export function buildSyntheticBackup(messages, key32) {
  const key16 = segmentKey16(key32);
  return messages.map((m) => {
    const proto = encodeMessage(m);
    const cipher = encryptSegment(proto, key16);
    return { proto, cipher };
  });
}
