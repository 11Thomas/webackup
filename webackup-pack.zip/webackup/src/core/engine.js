// core/engine.js — 备份/恢复编排：连接 协议源 <-> 加密存储
import { CHUNK_SIZE } from '../storage/store.js';

function genSnapId() {
  return 'snap_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
}

function splitChunks(buf, size = CHUNK_SIZE) {
  const out = [];
  for (let i = 0; i < buf.length; i += size) out.push(buf.subarray(i, i + size));
  return out;
}

// 执行一次备份：source(BackupSource) -> 加密分块存储 -> 清单 + 索引
export async function makeBackup(store, account, source, { dek, kek, kind = 'full', retention } = {}) {
  const snapId = genSnapId();
  const idx = store.readIndex(account, dek);
  const parent = idx.snapshots.length ? idx.snapshots[idx.snapshots.length - 1].id : null;

  const sessionsMeta = [];
  let msgCount = 0;
  let sizeBytes = 0;

  for await (const session of source.sessions()) {
    const payload = Buffer.from(JSON.stringify({
      id: session.id, name: session.name, type: session.type,
      messages: session.messages || [],
    }), 'utf8');
    const chunkRefs = [];
    for (const part of splitChunks(payload)) {
      const hash = store.writeChunk(account, part, dek);
      chunkRefs.push({ hash, len: part.length });
    }
    const sc = (session.messages || []).length;
    msgCount += sc;
    sizeBytes += payload.length;
    sessionsMeta.push({ id: session.id, name: session.name, type: session.type, chunkRefs, msgCount: sc });
  }

  const manifest = {
    id: snapId, type: kind, time: Date.now(), parent,
    sizeBytes, msgCount, sessionCount: sessionsMeta.length, sessions: sessionsMeta,
  };
  store.writeManifest(account, snapId, manifest, dek, kek);

  idx.snapshots.push({
    id: snapId, type: kind, time: manifest.time, sizeBytes, msgCount,
    sessionCount: sessionsMeta.length, status: 'ok', verified: false,
  });
  store.writeIndex(account, idx, dek);

  if (retention) store.enforceRetention(account, dek, retention);

  return { id: snapId, type: kind, sessionCount: sessionsMeta.length, msgCount, sizeBytes };
}

// 恢复：读清单 -> 解密选取会话 -> 推给 sink(RestoreSink)
export async function restore(store, account, snapId, sink, { dek, kek, sessions: selectedIds } = {}) {
  const manifest = store.readManifest(account, snapId, dek, kek);
  await sink.begin();
  let count = 0;
  for (const meta of manifest.sessions) {
    if (selectedIds && !selectedIds.includes(meta.id)) continue;
    const parts = [];
    for (const ref of meta.chunkRefs) parts.push(store.readChunk(account, ref.hash, dek));
    const session = JSON.parse(Buffer.concat(parts).toString('utf8'));
    await sink.writeSession(session);
    count++;
  }
  await sink.end();
  return { sessions: count, snapId };
}
