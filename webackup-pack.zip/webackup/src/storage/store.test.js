import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Store } from './store.js';
import * as kms from '../crypto/kms.js';

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), 'webackup-')); }

test('密钥库初始化 + 口令/恢复码解锁', () => {
  const store = new Store(tmp());
  const { recoveryCode } = store.initAccount('wx_alice', 'Str0ng#Pass');
  const a = store.unlock('wx_alice', 'Str0ng#Pass');
  assert.equal(a.dek.length, 32);
  const b = store.unlock('wx_alice', recoveryCode);
  assert.ok(b.dek.equals(a.dek));
});

test('块写入/读取往返 + 去重', () => {
  const store = new Store(tmp());
  const { dek } = store.initAccount('wx_bob', 'Str0ng#Pass');
  const p1 = Buffer.from('相同内容'.repeat(1000));
  const h1 = store.writeChunk('wx_bob', p1, dek);
  const h1b = store.writeChunk('wx_bob', p1, dek);
  assert.equal(h1, h1b); // 去重：同一明文同一哈希
  const back = store.readChunk('wx_bob', h1, dek);
  assert.ok(back.equals(p1));
});

test('清单加密 + HMAC 篡改检测', () => {
  const store = new Store(tmp());
  const { dek, kek } = store.initAccount('wx_c', 'Str0ng#Pass');
  store.writeManifest('wx_c', 's1', { hello: 'world', n: 1 }, dek, kek);
  const m = store.readManifest('wx_c', 's1', dek, kek);
  assert.equal(m.hello, 'world');
  // 篡改磁盘文件
  const fp = path.join(store.accountDir('wx_c'), 'snapshots', 's1', 'manifest.hmac');
  fs.writeFileSync(fp, Buffer.alloc(32, 9));
  assert.throws(() => store.readManifest('wx_c', 's1', dek, kek));
});

test('保留策略裁剪快照', () => {
  const store = new Store(tmp());
  const { dek } = store.initAccount('wx_d', 'Str0ng#Pass');
  const idx = { snapshots: [
    { id: 's1', time: Date.now() - 10 * 86400000 },
    { id: 's2', time: Date.now() - 2 * 86400000 },
    { id: 's3', time: Date.now() },
  ] };
  store.writeIndex('wx_d', idx, dek);
  const kept = store.enforceRetention('wx_d', dek, { keepDays: 5 });
  assert.deepEqual(kept.map((s) => s.id), ['s2', 's3']);
});
