// storage/store.js — 加密存储引擎：密钥库、内容寻址去重块、加密清单、账号索引
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import * as kms from '../crypto/kms.js';

const CHUNK_SIZE = 4 * 1024 * 1024; // 生产 4-8MB；测试可调小

export class Store {
  constructor(rootDir) {
    this.root = rootDir;
    fs.mkdirSync(rootDir, { recursive: true });
  }

  accountDir(account) { return path.join(this.root, account); }
  keystorePath(account) { return path.join(this.accountDir(account), 'keystore.json'); }
  keystoreExists(account) { return fs.existsSync(this.keystorePath(account)); }

  // 初始化账号密钥库：生成 DEK，分别用口令 KEK 与恢复码 KEK 包裹
  initAccount(account, passphrase) {
    if (this.keystoreExists(account)) throw new Error('账号已存在');
    const salt = kms.randomBytes(16);
    const kek = kms.deriveKEK(passphrase, salt);
    const dek = kms.genDEK();
    const recoveryCode = kms.genRecoveryCode();
    const recoverySalt = kms.randomBytes(16);
    const recoveryKEK = kms.deriveKEK(kms.recoveryCodeToBytes(recoveryCode), recoverySalt);
    const ks = {
      version: 1,
      kdf: { salt: salt.toString('base64'), N: 1 << 15, r: 8, p: 1, keylen: 32 },
      wrappedDEK: blob(kms.wrapDEK(dek, kek)),
      recoverySalt: recoverySalt.toString('base64'),
      recoveryWrappedDEK: blob(kms.wrapDEK(dek, recoveryKEK)),
    };
    fs.mkdirSync(this.accountDir(account), { recursive: true });
    fs.writeFileSync(this.keystorePath(account), JSON.stringify(ks, null, 2));
    return { recoveryCode, dek, kek };
  }

  // 用口令或恢复码解锁，返回 {dek, kek}
  unlock(account, secret) {
    const ks = this.loadKeystore(account);
    const kek = kms.deriveKEK(secret, Buffer.from(ks.kdf.salt, 'base64'));
    try {
      const dek = kms.unwrapDEK(unblob(ks.wrappedDEK), kek);
      return { dek, kek };
    } catch {
      // 尝试恢复代码
      const rkek = kms.deriveKEK(kms.recoveryCodeToBytes(String(secret)), Buffer.from(ks.recoverySalt, 'base64'));
      const dek = kms.unwrapDEK(unblob(ks.recoveryWrappedDEK), rkek);
      return { dek, kek: rkek };
    }
  }

  // 更换口令：用新 KEK 重包 DEK（DEK 不变，数据块无需重写）
  rotatePassphrase(account, oldSecret, newPassphrase) {
    const { dek } = this.unlock(account, oldSecret);
    const ks = this.loadKeystore(account);
    const salt = kms.randomBytes(16);
    const kek = kms.deriveKEK(newPassphrase, salt);
    ks.kdf = { salt: salt.toString('base64'), N: 1 << 15, r: 8, p: 1, keylen: 32 };
    ks.wrappedDEK = blob(kms.wrapDEK(dek, kek));
    fs.writeFileSync(this.keystorePath(account), JSON.stringify(ks, null, 2));
    return { kek, dek };
  }

  // 写入加密块，按明文 SHA-256 去重
  writeChunk(account, plain, dek) {
    const h = kms.sha256(plain);
    const dir = path.join(this.accountDir(account), 'chunks');
    fs.mkdirSync(dir, { recursive: true });
    const fp = path.join(dir, h);
    if (!fs.existsSync(fp)) {
      fs.writeFileSync(fp, kms.serializeBlob(kms.encryptBuf(plain, dek)));
    }
    return h;
  }

  readChunk(account, hash, dek) {
    const fp = path.join(this.accountDir(account), 'chunks', hash);
    return kms.decryptBuf(kms.parseBlob(fs.readFileSync(fp)), dek);
  }

  // 快照清单：加密 + HMAC(KEK)
  writeManifest(account, snapId, manifestObj, dek, kek) {
    const sdir = path.join(this.accountDir(account), 'snapshots', snapId);
    fs.mkdirSync(sdir, { recursive: true });
    const blobBuf = kms.serializeBlob(kms.encryptBuf(Buffer.from(JSON.stringify(manifestObj)), dek));
    const mac = kms.hmacSHA256(blobBuf, kek);
    fs.writeFileSync(path.join(sdir, 'manifest.bin'), blobBuf);
    fs.writeFileSync(path.join(sdir, 'manifest.hmac'), mac);
    return mac.toString('hex');
  }

  readManifest(account, snapId, dek, kek) {
    const sdir = path.join(this.accountDir(account), 'snapshots', snapId);
    const blobBuf = fs.readFileSync(path.join(sdir, 'manifest.bin'));
    const mac = fs.readFileSync(path.join(sdir, 'manifest.hmac'));
    const expect = kms.hmacSHA256(blobBuf, kek);
    if (!crypto.timingSafeEqual(mac, expect)) throw new Error('清单 HMAC 校验失败（可能被篡改）');
    return JSON.parse(kms.decryptBuf(kms.parseBlob(blobBuf), dek).toString('utf8'));
  }

  // 账号索引（加密，含快照元数据，无消息内容）
  writeIndex(account, indexObj, dek) {
    const enc = kms.serializeBlob(kms.encryptBuf(Buffer.from(JSON.stringify(indexObj)), dek));
    fs.writeFileSync(path.join(this.accountDir(account), 'index.bin'), enc);
  }
  readIndex(account, dek) {
    const fp = path.join(this.accountDir(account), 'index.bin');
    if (!fs.existsSync(fp)) return { snapshots: [] };
    return JSON.parse(kms.decryptBuf(kms.parseBlob(fs.readFileSync(fp)), dek).toString('utf8'));
  }

  listSnapshots(account, dek) {
    return this.readIndex(account, dek).snapshots;
  }

  // 保留策略：按份数或天数裁剪（仅删除元数据引用，块由 GC 清理）
  enforceRetention(account, dek, policy = {}) {
    const idx = this.readIndex(account, dek);
    let snaps = idx.snapshots;
    if (policy.keepCount && snaps.length > policy.keepCount) {
      snaps = snaps.slice(snaps.length - policy.keepCount);
    }
    if (policy.keepDays) {
      const cut = Date.now() - policy.keepDays * 86400000;
      snaps = snaps.filter((s) => s.time >= cut);
    }
    idx.snapshots = snaps;
    this.writeIndex(account, idx, dek);
    return snaps;
  }

  loadKeystore(account) {
    if (!this.keystoreExists(account)) throw new Error('账号不存在');
    return JSON.parse(fs.readFileSync(this.keystorePath(account), 'utf8'));
  }
}

function blob({ nonce, tag, ct }) {
  return { nonce: nonce.toString('base64'), tag: tag.toString('base64'), ct: ct.toString('base64') };
}
function unblob(b) {
  return { nonce: Buffer.from(b.nonce, 'base64'), tag: Buffer.from(b.tag, 'base64'), ct: Buffer.from(b.ct, 'base64') };
}

export { CHUNK_SIZE };
