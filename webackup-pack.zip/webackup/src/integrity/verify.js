// integrity/verify.js — 备份完整性校验：块标签/哈希 + 清单 HMAC
import { Store } from '../storage/store.js';
import * as kms from '../crypto/kms.js';

// 校验单个快照：返回 {ok, snapId, totalChunks, badChunks, manifestOK, checkedAt}
export function verifySnapshot(store, account, snapId, dek, kek) {
  let manifestOK = false;
  let manifest;
  try {
    manifest = store.readManifest(account, snapId, dek, kek); // 内含 HMAC 校验
    manifestOK = true;
  } catch (e) {
    return { ok: false, snapId, totalChunks: 0, badChunks: [], manifestOK: false, error: String(e.message || e), checkedAt: Date.now() };
  }
  const badChunks = [];
  let total = 0;
  for (const s of manifest.sessions || []) {
    for (const ref of s.chunkRefs || []) {
      total++;
      try {
        const buf = store.readChunk(account, ref.hash, dek);
        if (kms.sha256(buf) !== ref.hash) badChunks.push(ref.hash);
      } catch {
        badChunks.push(ref.hash);
      }
    }
  }
  return {
    ok: badChunks.length === 0,
    snapId,
    totalChunks: total,
    badChunks,
    manifestOK,
    checkedAt: Date.now(),
  };
}

// 校验账号下全部快照
export function verifyAccount(store, account, dek, kek) {
  const snaps = store.listSnapshots(account, dek);
  return snaps.map((s) => verifySnapshot(store, account, s.id, dek, kek));
}

export function summarize(reports) {
  const bad = reports.filter((r) => !r.ok).length;
  return { total: reports.length, bad, healthy: reports.length - bad };
}
