import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Store } from '../storage/store.js';
import { verifySnapshot } from './verify.js';
import { makeBackup } from '../core/engine.js';

function tmp() { return fs.mkdtempSync(path.join(os.tmpdir(), 'webackup-int-')); }

test('校验通过的健康快照', async () => {
  const dir = tmp();
  const store = new Store(dir);
  const { dek, kek } = store.initAccount('wx_x', 'Str0ng#Pass');
  const src = {
    async *sessions() {
      yield { id: 's1', name: '好友A', type: 'friend', messages: [{ id: 1, ts: 1, sender: 'me', kind: 'text', text: 'hi' }] };
    },
  };
  const manifest = await makeBackup(store, 'wx_x', src, { dek, kek, kind: 'full' });
  const rep = verifySnapshot(store, 'wx_x', manifest.id, dek, kek);
  assert.equal(rep.ok, true);
  assert.ok(rep.totalChunks >= 1);
});

test('块损坏可被检出', async () => {
  const dir = tmp();
  const store = new Store(dir);
  const { dek, kek } = store.initAccount('wx_y', 'Str0ng#Pass');
  const src = {
    async *sessions() {
      yield { id: 's1', name: 'B', type: 'friend', messages: [{ id: 1, ts: 1, sender: 'me', kind: 'text', text: 'secret' }] };
    },
  };
  const manifest = await makeBackup(store, 'wx_y', src, { dek, kek, kind: 'full' });
  // 破坏某个块文件
  const chunkDir = path.join(store.accountDir('wx_y'), 'chunks');
  const f = fs.readdirSync(chunkDir)[0];
  const p = path.join(chunkDir, f);
  const buf = fs.readFileSync(p);
  buf[20] ^= 0xff;
  fs.writeFileSync(p, buf);
  const rep = verifySnapshot(store, 'wx_y', manifest.id, dek, kek);
  assert.equal(rep.ok, false);
  assert.ok(rep.badChunks.length >= 1);
});
