# WeBackup · 飞牛 fnOS 微信聊天记录备份应用

端到端加密、本地化存储于飞牛 NAS 的微信聊天记录备份/恢复应用。数据**零知识托管**：NAS 上只存密文，口令与数据密钥（DEK）明文不落盘。

> 应用代号 **WeBackup（微备）**。源码为纯 Node.js 标准库实现（零外部依赖），便于离线构建与审计。

---

## 一、已经实现（本仓库可直接运行/测试）

- **安全核心**：信封加密（KEK 由口令派生 → 包裹 DEK；DEK 做 AES-256-GCM 块加密）、HMAC 清单防篡改、恢复代码、密钥文件导出/导入、口令轮换。带单元测试。
- **加密存储引擎**：内容寻址块存储 + 去重、加密清单、账号索引、保留策略。带单元测试。
- **完整性校验**：逐块 GCM 标签/SHA-256 校验 + 清单 HMAC，产出报告。带单元测试（含块损坏检出）。
- **协议层（可插拔）**：
  - `FileImportSource` / `FileExportSink` —— 文件导入/导出适配器，**已打通端到端备份↔恢复链路**（无需真机）。
  - `WeChatBackupServer` / `WeChatRestoreSink` —— **已补全**微信 3.x「备份到电脑」接收服务：
    - 会话密钥生成与下发（32 字节，前 16 字节用于片段 AES-ECB）；
    - 传输阶段按微信磁盘格式接收 → AES-ECB 解密 → protobuf 解码 → 结构化会话；
    - `Backup.db` 的 SQLCipher3 解密 + 最小 SQLite 读取（`loadBackupFromDisk` 导入已有 Windows 备份）；
    - 抓包记录与回放（`capture-harness.md`）。**活体握手为私有协议，已在传输层之上以 emulation 契约对齐同一套密码学，抓到真机握手后只需替换握手分支。**
- **定时调度**：轻量 cron（`daily/weekly/monthly/interval/cron`）。
- **Web 管理端**：管理员登录 + 每账号零知识解锁；仪表盘、快照管理、立即备份（支持 `file` 与 `wechat` 两类源）、恢复、校验、密钥管理（恢复代码展示/密钥文件导出/口令轮换）、备份计划。
- **全流程单测 22/22 通过**（含 HTTP 端到端：设置→建账号→解锁→备份→校验→恢复；安装向导种子自动初始化；及协议层 9 例：片段加解密、protobuf、decryptBackupDb、最小 SQLite 解析、TCP 端到端、回放、引擎端到端）。

## 二、与已批准方案的偏差（环境所限，已注明）

| 项 | 方案原计划 | 本仓库实现 | 说明 |
|---|---|---|---|
| 主语言 | Go 1.22 | **Node.js 22** | 沙箱无 Go 工具链且无外网，Node 可用、纯标准库、可离线验证。fnOS 应用是 Docker 容器，语言为实现细节。生产可平移到 Go。 |
| KDF | Argon2id | **scrypt**（内存硬） | 无外部依赖且抗暴力；生产建议升级 Argon2id（需引入 `golang.org/x/crypto/argon2` 或等价）。 |
| 元数据 | SQLite | **加密 JSON 索引** | 零外部依赖；无消息内容，仅快照元数据。 |
| 协议源 | 官方协议服务端 | **WeChatBackupServer 已补全（3.x 片段密码学/protobuf/SQLCipher 均验证）**；活体握手为私有协议，以 emulation 契约对齐，待真机抓包补全握手分支 | 最高风险模块，密码学已就绪，握手字节需抓包（见 `capture-harness.md` 第 4 节）。 |

## 三、数据安全设计

- **端到端/零知识**：口令 → scrypt → KEK；随机 DEK 用 AES-256-GCM 加密数据块；磁盘仅存 `KEK 包裹的 DEK` + 盐 + 密文。**NAS 运维/进程均无法解密。**
- **传输**：手机↔NAS 走局域网；微信传输层在 NAS 内存解密后立即重加密，明文不落盘。协议端口严禁裸暴露公网，远程必须经 FN Connect/VPN。
- **完整性**：每块 GCM 标签 + 明文 SHA-256；清单 HMAC(KEK)；可周期校验并报警。
- **密钥管理**：首次强制设置强口令并展示**恢复代码**；支持密钥文件导出（离 NAS 即削弱零知识，已提示）；口令遗失且恢复代码/密钥文件皆丢 = 不可恢复，UI 强提示。
- **隐私红线**：绝不外联上传、无遥测；日志不记消息内容/联系人明文；管理面需登录。

## 四、本地运行与测试

```bash
# 1) 生成示例「已解密导出目录」（供文件导入端到端验证）
node src/cli.js sample ./import

# 2) 启动管理端（默认 http://127.0.0.1:8099）
WEBACKUP_DATA_DIR=./data WEBACKUP_EXPORT_DIR=./import PORT=8099 node src/index.js

# 3) 浏览器打开后：首次设置管理员 → 新建微信账号（抄存恢复代码）→ 解锁 → 立即备份 → 校验/恢复

# 4) 运行单元测试（22 例，含协议层 9 例 + 引导种子）
node --test
```

### 手机微信直连备份（需真机/局域网）

解锁账号后，调用备份接口并指定 `source:"wechat"`，服务会在飞牛 NAS 上监听微信官方端口
（默认 `8011`/`24011`，与 WxBackup 一致），手机微信「备份与恢复 → 备份聊天记录到电脑」
选择本机即可直连（免 root/越狱）：

```bash
curl -b "wb_acct=<解锁后 cookie>" -X POST \
  http://127.0.0.1:8080/api/accounts/<wxid>/backup \
  -H 'Content-Type: application/json' \
  -d '{"source":"wechat","kind":"full","ports":[8011,24011]}'
```

- 传输层在 NAS 内存解密后立即重加密落盘（明文不落盘）；`captureDir` 可记录原始字节供回放分析。
- 片段密码学（AES-ECB 前 16 字节密钥 / protobuf / SQLCipher3）已用单测验证；
  真机活体握手为私有协议，抓包后仅需替换 `WeChatBackupServer` 握手分支（见 `capture-harness.md` 第 4 节）。

## 五、打包为飞牛 `.fpk`（在真实 fnOS + fnpack 上执行）

`deploy/fnos/` 已按 fnOS 第三方 Docker 应用最新规范写成**可直接 `fnpack build` 的工程**（manifest / cmd/main / config/{privilege,resource} / wizard/install / app/{ui,docker} / ICON.PNG + ICON_256.PNG 齐全）。

### 目录结构（打包工程）
```
deploy/fnos/
├── manifest                      # INI：appname=com.webackup.app, service_port=8099, desktop_uidir, ...
├── ICON.PNG / ICON_256.PNG       # 应用图标（tools/gen-icons.mjs 生成）
├── config/
│   ├── privilege                 # JSON：网络/存储权限声明
│   └── resource                  # JSON：{"docker-project":{"projects":[{"name":"webackup","path":"docker"}]}}
├── cmd/
│   ├── main                      # bash：start/stop/status（status 退出码 3=已停止，用 label 检测容器）
│   └── install_callback          # 安装后写入 ${TRIM_PKGVAR}/admin.seed.json（向导账号口令）
├── wizard/install                # JSON：安装向导（管理员账号/口令/管理端口）
└── app/
    ├── ui/config                 # 桌面入口（图标 + 跳转 http://127.0.0.1:8099）
    └── docker/docker-compose.yaml# 端口 8099、label、healthcheck，image 用 __WEBACKUP_IMAGE__ 占位
```

### 一键构建脚本（推荐）
`scripts/build-fpk.sh` 在「有 Docker + fnpack + 外网」的机器/CI 上执行（环境变量：`REGISTRY` / `REPO` / `TAG`，默认 `ghcr.io` / `webackup/webackup` / 取 `package.json` version）：
```bash
REGISTRY=ghcr.io REPO=yourname/webackup TAG=0.1.0 \
  FNPACK_BIN=/usr/local/bin/fnpack bash scripts/build-fpk.sh
# 产物在 ./dist-fpk/webackup-0.1.0.fpk
```
它会：① `docker build` 并 `docker push` 到 `${DOCKERHUB_REPO}/webackup:${FPK_IMAGE_TAG}`；
② 把该镜像替换进 `docker-compose.yaml`（覆盖 `__WEBACKUP_IMAGE__` 占位符）；
③ 调用 `fnpack build` 生成 `.fpk`（fnpack 仅校验文件存在与 JSON 合法性）。

### GitHub Actions（CI 出包）
`.github/workflows/build-fpk.yml`：push tag `v*` 时自动构建镜像、替换 compose、`fnpack build`，上传 `.fpk` 为产物。**需在仓库 Secrets 配置 `DOCKERHUB_REPO` / `DOCKERHUB_TOKEN` 与 `FNPACK`（fnpack 可执行文件或安装命令）。**

### 安装到飞牛
1. 飞牛「应用中心 → 手动安装」上传 `.fpk`。
2. 安装向导填写管理员账号/口令/管理端口（`install_callback` 据此写入一次性种子文件）。
3. 数据卷由系统托管在 `${TRIM_PKGVAR}/data`，升级不丢数据；端口默认 `8099`。
4. 桌面点击「WeBackup」即跳转到 `http://127.0.0.1:8099`。

> 说明：本仓库在沙箱内无 Docker/fnpack/外网，无法在此直接产出 `.fpk` 二进制；以上脚本与工程在具备环境的机器/CI 上即可生成。上架前请在真实 fnOS 对照 developer.fnnas.com 复核 `manifest` 字段与 `wizard` 表单（不同 fnOS 版本字段可能微调）。当前 fnOS 三方应用仅 x86_64，镜像须为 linux/amd64。

### 零基础一键出包（推荐：GitHub Actions，本机不用装任何东西）

你只需要一个**免费 GitHub 账号**，全程点鼠标，本机不用装 Docker、不用配任何密钥。

1. 注册 GitHub：https://github.com （免费）。
2. 新建仓库：右上角 “+” → New repository → 名字填 `webackup` → 选 **Public** → Create repository。
3. 上传代码：仓库页 “Add file” → “Upload files” → 把本仓库 `webackup/` 整个文件夹拖进去（子文件夹一并拖）→ 写个说明 → Commit changes。
   - 嫌拖文件麻烦？直接用本仓库附带的 `webackup-pack.zip` 解压后整体上传即可。
4. 触发打包：点仓库顶部 **Actions** → 左侧 “Build WeBackup .fpk” → 右侧 **Run workflow** → 分支 `main`、版本填 `0.1.0` → Run workflow。
5. 等几分钟（出现绿色 ✓）→ 点进这次运行 → 底部 **Artifacts** → 下载 `webackup-fpk.zip` → 解压得到 `webackup-0.1.0.fpk`。
6. 飞牛「应用中心 → 手动安装」上传该 `.fpk` → 向导填管理员账号/口令 → 完成。镜像已自动设为公开，飞牛能直接拉取。

> 全程不需要 Docker Hub 账号、不需要任何 Secret。镜像推到 GitHub 自带的 GHCR（用内置 token），工作流会自动把包设为 Public。

### 在飞牛 NAS 上直接出包（适合你已有飞牛 + 能远程开终端的用户，推荐）

飞牛 fnOS 自带 Docker 和 `fnpack`，所以**最顺的路是在飞牛本机直接 build + 打包**，你自己的电脑什么都不用装：

1. 把整个 `webackup/` 工程传到飞牛（用飞牛「文件管理」拖进去，或飞牛终端 `git clone`）。
2. 在飞牛里打开「终端」App（或 SSH 连飞牛），`cd` 进工程目录。
3. 执行：
   ```bash
   bash scripts/build-on-fnos.sh
   ```
   脚本会：构建镜像 → 起一个**本地镜像仓库**（`127.0.0.1:5000`，这样 .fpk 安装时不用再去外网拉）→ 把 compose 镜像地址改成这个本地仓库 → 用飞牛自带 `fnpack build` 出包。
4. 按屏幕提示，飞牛「应用中心 → 手动安装」选生成的 `.fpk` → 向导填管理员账号口令。

> 前提：飞牛 NAS 能联网（至少能拉一次 Docker Hub 基础镜像）。判断：你能正常在飞牛应用中心装官方应用，就说明能联网。若完全不能联网，则本方案不可行，需先让飞牛能联网。

### 更省事：免 .fpk，直接在飞牛跑容器（步骤最少）

如果你不在乎「应用中心入口/安装向导」这些外壳，只想赶快用上，可以**完全不打包 .fpk**，直接在飞牛把容器跑起来：

```bash
# 在飞牛终端执行（先构建镜像）
docker build --platform linux/amd64 -t webackup:0.1.0 -f Dockerfile .
# 运行（把数据存到飞牛持久目录，端口映射 8099）
docker run -d --name webackup -p 8099:8099 \
  -v /vol1/@app/webackup/data:/app/data \
  -e PORT=8099 webackup:0.1.0
```

然后浏览器开 `http://飞牛IP:8099` → 首次设置管理员 → 新建微信账号（抄存恢复代码）→ 解锁 → 立即备份。
（飞牛「Docker」App 里也能用图形界面做同样的事：构建/拉镜像 → 建容器 → 映射 8099 → 挂数据卷。）

## 六、后续攻坚（P2 协议服务）

目标：手机微信免 root/越狱直连 NAS 备份。路线见 `src/protocol/capture-harness.md`：
1. PC 微信「备份到电脑」抓包，解析握手/会话密钥协商/protobuf/增量判定。
2. 在 `WeChatBackupServer` 实现同端口、同握手；`sessions()` 按抓包格式产出会话。
3. `engine.makeBackup` 已封装「内存解密→重加密落盘」路径，直接复用。
4. 增量按 `parent` 快照游标；恢复为反向通道。
5. 若某版本协议被封，回退 `FileImportSource`（桌面代理导入）保证链路可用。

## 七、合规提示

模拟微信官方协议可能触及其服务条款。定位为「个人数据备份工具」，不破解账号、不碰非本人数据，上线前做法律自评。

## 目录结构

```
webackup/
├── package.json
├── Dockerfile
├── src/
│   ├── crypto/kms.js          安全内核（KDF/信封加密/HMAC/恢复代码）
│   ├── storage/store.js       加密存储引擎（块/去重/清单/索引）
│   ├── integrity/verify.js     完整性校验
│   ├── protocol/               协议层（fileimport 可用 / wechatd 桩 / 抓包台）
│   ├── scheduler/scheduler.js  定时调度
│   ├── core/engine.js          备份/恢复编排
│   ├── api/server.js           HTTP API + 两层鉴权
│   └── index.js / cli.js       入口 / 运维命令
├── web/                        管理端 SPA（无构建步骤）
├── deploy/fnos/                .fpk 打包工程（manifest/cmd/compose/wizard/icon）
└── tools/gen-icons.mjs        图标生成
```
