// web/app.js — 管理端单页逻辑（原生 JS，无构建步骤）
const state = { setup: false, admin: false, accounts: [], current: null };

async function jfetch(url, opts = {}) {
  const r = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
  return data;
}
const $ = (id) => document.getElementById(id);

function show(view) {
  ['view-setup', 'view-login', 'view-home', 'view-account'].forEach((v) => $(v).classList.add('hidden'));
  if (view) $(view).classList.remove('hidden');
}

const UI = {
  goHome() { state.current = null; show('view-home'); API.refresh(); },
  setUser(txt) { $('userbox').textContent = txt || ''; },
};

const API = {
  async init() {
    try {
      const s = await jfetch('/api/status');
      state.setup = s.setup; state.admin = s.admin; state.accounts = s.accounts || [];
      if (!s.setup) show('view-setup');
      else if (!s.admin) show('view-login');
      else { show('view-home'); this.refresh(); }
    } catch (e) { alert('无法连接服务：' + e.message); }
  },
  async setup() {
    try {
      await jfetch('/api/setup', { method: 'POST', body: JSON.stringify({ user: $('su-user').value, password: $('su-pass').value }) });
      state.setup = true; this.init();
    } catch (e) { alert(e.message); }
  },
  async login() {
    try {
      await jfetch('/api/login', { method: 'POST', body: JSON.stringify({ user: $('lg-user').value, password: $('lg-pass').value }) });
      state.admin = true; show('view-home'); this.refresh();
    } catch (e) { alert(e.message); }
  },
  async logout() {
    await jfetch('/api/logout', { method: 'POST' }); state.admin = false; show('view-login');
  },
  async refresh() {
    const s = await jfetch('/api/status');
    state.accounts = s.accounts || [];
    const box = $('accounts'); box.innerHTML = '';
    if (!state.accounts.length) box.innerHTML = '<p class="muted">暂无账号，请在下方创建。</p>';
    for (const a of state.accounts) {
      const d = document.createElement('div'); d.className = 'tile';
      d.innerHTML = `<div class="t">${a.id}</div><div class="s">已加密 · 零知识</div>`;
      d.onclick = () => this.openAccount(a.id);
      box.appendChild(d);
    }
    const pl = await jfetch('/api/plans');
    $('plans').innerHTML = (pl.plans || []).map((p) => `<div class="tile"><div class="t">${p.account}</div><div class="s">${p.schedule} · ${p.kind || 'incremental'}</div></div>`).join('') || '<p class="muted">暂无计划</p>';
  },
  async createAccount() {
    try {
      const r = await jfetch('/api/accounts', { method: 'POST', body: JSON.stringify({ account: $('na-account').value, passphrase: $('na-pass').value, confirm: $('na-confirm').value }) });
      $('na-recovery').classList.remove('hidden');
      $('na-recovery').textContent = '恢复代码（请抄存，遗失且忘口令将无法恢复）：\n' + r.recoveryCode;
      $('na-account').value = ''; $('na-pass').value = ''; $('na-confirm').value = '';
      this.refresh();
    } catch (e) { alert(e.message); }
  },
  async openAccount(id) {
    state.current = id; $('acc-title').textContent = '账号：' + id;
    const info = await jfetch('/api/accounts/' + id);
    if (info.locked) {
      $('acc-lock').classList.remove('hidden'); $('acc-body').classList.add('hidden');
      $('acc-lock').innerHTML = `<p class="muted">该账号已加密，需输入口令（或恢复代码）解锁后查看/操作。</p>
        <input id="un-secret" type="password" placeholder="备份口令 / 恢复代码" />
        <button onclick="API.unlock()">解锁</button>`;
    } else {
      $('acc-lock').classList.add('hidden'); $('acc-body').classList.remove('hidden');
      this.loadSnapshots(id);
    }
    show('view-account');
  },
  async unlock() {
    try {
      await jfetch('/api/accounts/' + state.current + '/unlock', { method: 'POST', body: JSON.stringify({ secret: $('un-secret').value }) });
      $('acc-lock').classList.add('hidden'); $('acc-body').classList.remove('hidden');
      this.loadSnapshots(state.current);
    } catch (e) { alert(e.message); }
  },
  async loadSnapshots(id) {
    const s = await jfetch('/api/accounts/' + id + '/snapshots');
    const box = $('snapshots'); box.innerHTML = '';
    for (const snap of (s.snapshots || []).reverse()) {
      const d = document.createElement('div'); d.className = 'tile';
      const t = new Date(snap.time).toLocaleString();
      d.innerHTML = `<div class="t">${snap.type} · ${t}</div>
        <div class="s">会话 ${snap.sessionCount} · 消息 ${snap.msgCount} · ${(snap.sizeBytes/1024).toFixed(1)}KB</div>
        <div style="margin-top:8px;display:flex;gap:6px">
          <button class="ghost" onclick="API.restore('${snap.id}')">恢复</button>
          <button class="ghost" onclick="API.verify('${snap.id}')">校验</button>
        </div>`;
      box.appendChild(d);
    }
  },
  async backup() {
    try { const r = await jfetch('/api/accounts/' + state.current + '/backup', { method: 'POST', body: JSON.stringify({ kind: 'incremental' }) }); alert('备份完成：' + JSON.stringify(r)); this.loadSnapshots(state.current); } catch (e) { alert(e.message); }
  },
  async restore(snapId) {
    try { const r = await jfetch('/api/accounts/' + state.current + '/restore', { method: 'POST', body: JSON.stringify({ snapId }) }); alert('已恢复导出到 restore_out：' + JSON.stringify(r)); } catch (e) { alert(e.message); }
  },
  async verify(snapId) {
    try { const r = await jfetch('/api/accounts/' + state.current + '/verify/' + snapId); alert('校验：' + (r.ok ? '通过' : '异常 ' + JSON.stringify(r.badChunks))); } catch (e) { alert(e.message); }
  },
  async verifyAll() {
    try { const r = await jfetch('/api/accounts/' + state.current + '/verify'); alert('全部校验：' + JSON.stringify(r.summary)); } catch (e) { alert(e.message); }
  },
  async showKeyfile() {
    const r = await jfetch('/api/accounts/' + state.current + '/key');
    $('keyfile').classList.remove('hidden');
    $('keyfile').textContent = JSON.stringify(r.keyfile, null, 2);
  },
  async rotateKey() {
    const oldSecret = prompt('请输入当前口令/恢复代码'); const np = prompt('请输入新口令');
    try { await jfetch('/api/accounts/' + state.current + '/key/rotate', { method: 'POST', body: JSON.stringify({ oldSecret, newPassphrase: np }) }); alert('口令已轮换'); } catch (e) { alert(e.message); }
  },
  async addPlan() {
    try { await jfetch('/api/plans', { method: 'POST', body: JSON.stringify({ account: $('pl-account').value, schedule: $('pl-schedule').value, kind: 'incremental' }) }); this.refresh(); } catch (e) { alert(e.message); }
  },
};

API.init();
