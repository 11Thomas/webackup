// web/app.js — 微备份 单页管理端（原生 JS，无构建步骤）
const $ = (id) => document.getElementById(id);
const state = { setup: false, admin: false, user: '', projects: [], schedules: [], stats: {}, currentProject: null, currentTab: 'snapshots' };

async function jfetch(url, opts = {}) {
  const r = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
  return data;
}

function toast(msg, type = 'info') {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show' + (type === 'error' ? ' error' : '');
  setTimeout(() => t.classList.remove('show'), 2600);
}

function fmtDate(ts) {
  if (!ts) return '-';
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
function fmtSize(n) {
  if (!n) return '0 B';
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
  return (n / 1024 / 1024 / 1024).toFixed(1) + ' GB';
}

function showViews(names) {
  ['view-auth', 'view-home', 'view-projects', 'view-new-project', 'view-project', 'view-schedules', 'view-new-schedule', 'view-settings'].forEach((id) => {
    $(id).classList.toggle('hidden', !names.includes(id));
  });
}

function setActive(route) {
  document.querySelectorAll('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.route === route));
}

const UI = {
  toggleSidebar() {
    $('sidebar').classList.toggle('open');
  },
  go(name) {
    const map = { home: '#/', projects: '#/projects', 'new-project': '#/new-project', schedules: '#/schedules', 'new-schedule': '#/new-schedule', settings: '#/settings' };
    location.hash = map[name] || '#/';
  },
  setTitle(t) {
    $('page-title').textContent = t;
  },
  pTab(tab) {
    state.currentTab = tab;
    document.querySelectorAll('.tab').forEach((el) => el.classList.toggle('active', el.dataset.tab === tab));
    document.querySelectorAll('.tab-pane').forEach((el) => el.classList.toggle('active', el.id === 'tab-' + tab));
    if (tab === 'files') UI.loadSnapshotFiles();
    if (tab === 'restore') UI.loadRestoreSnaps();
  },
  loadSnapshotFiles() {
    const sel = $('p-snap-select');
    if (!sel.value) return;
    API.files(sel.value);
  },
  loadRestoreSnaps() {
    const snaps = (state.currentProject?.snapshots || []).slice().reverse();
    const sel = $('p-restore-snap');
    sel.innerHTML = snaps.map((s) => `<option value="${s.id}">${fmtDate(s.time)} · ${s.type || 'incremental'} · ${fmtSize(s.sizeBytes)}</option>`).join('');
  },
};

const API = {
  async init() {
    try {
      const s = await jfetch('/api/status');
      state.setup = s.setup;
      state.admin = s.admin;
      state.stats = s.stats || {};
      if (!state.admin) {
        $('sidebar').classList.add('hidden');
        $('topbar').classList.add('hidden');
        showViews(['view-auth']);
        if (!state.setup) {
          $('auth-title').textContent = '初始化微备份';
          $('auth-sub').textContent = '设置管理员账号后开始使用';
          $('auth-setup').classList.remove('hidden');
          $('auth-login').classList.add('hidden');
        } else {
          $('auth-title').textContent = '欢迎回到微备份';
          $('auth-sub').textContent = '请输入管理员口令登录';
          $('auth-setup').classList.add('hidden');
          $('auth-login').classList.remove('hidden');
        }
      } else {
        $('sidebar').classList.remove('hidden');
        $('topbar').classList.remove('hidden');
        $('user-name').textContent = '管理员';
        await this.refresh();
        router();
      }
    } catch (e) { toast('无法连接服务：' + e.message, 'error'); }
  },
  async setup() {
    try {
      await jfetch('/api/setup', { method: 'POST', body: JSON.stringify({ user: $('su-user').value, password: $('su-pass').value }) });
      state.setup = true;
      toast('初始化成功');
      this.init();
    } catch (e) { toast(e.message, 'error'); }
  },
  async login() {
    try {
      await jfetch('/api/login', { method: 'POST', body: JSON.stringify({ user: $('lg-user').value, password: $('lg-pass').value }) });
      state.admin = true;
      toast('登录成功');
      this.init();
    } catch (e) { toast(e.message, 'error'); }
  },
  async logout() {
    await jfetch('/api/logout', { method: 'POST' });
    state.admin = false;
    location.hash = '';
    location.reload();
  },
  async refresh() {
    try {
      const s = await jfetch('/api/status');
      state.stats = s.stats || {};
      const p = await jfetch('/api/projects');
      state.projects = p.projects || [];
      const sch = await jfetch('/api/schedules');
      state.schedules = sch.schedules || [];
      renderDashboard();
      renderProjects();
      renderSchedules();
    } catch (e) { toast('刷新失败：' + e.message, 'error'); }
  },
  async createProject() {
    try {
      const body = {
        name: $('np-name').value,
        source: $('np-path').value,
        passphrase: $('np-pass').value,
      };
      if ($('np-pass').value !== $('np-pass2').value) throw new Error('两次口令不一致');
      const r = await jfetch('/api/projects', { method: 'POST', body: JSON.stringify(body) });
      $('np-recovery').classList.remove('hidden');
      $('np-recovery').textContent = '恢复代码（请务必离线保存，遗失且忘记口令将无法恢复）：\n' + r.recoveryCode;
      $('np-name').value = ''; $('np-path').value = ''; $('np-pass').value = ''; $('np-pass2').value = '';
      await this.refresh();
    } catch (e) { toast(e.message, 'error'); }
  },
  async deleteProject(id) {
    if (!confirm('确定删除该项目及其所有备份？数据不可恢复。')) return;
    try {
      await jfetch('/api/projects', { method: 'DELETE', body: JSON.stringify({ id }) });
      await this.refresh();
      UI.go('projects');
    } catch (e) { toast(e.message, 'error'); }
  },
  async unlockProject(id) {
    try {
      await jfetch('/api/projects/' + id + '/unlock', { method: 'POST', body: JSON.stringify({ secret: $('p-secret').value }) });
      toast('项目已解锁');
      await this.openProject(id);
    } catch (e) { toast(e.message, 'error'); }
  },
  async lockProject() {
    if (!state.currentProject) return;
    await jfetch('/api/projects/' + state.currentProject.id + '/lock', { method: 'POST' });
    state.currentProject.locked = true;
    renderProject();
  },
  async openProject(id) {
    try {
      const info = await jfetch('/api/projects/' + id);
      const snaps = await jfetch('/api/projects/' + id + '/snapshots');
      state.currentProject = { ...info, snapshots: snaps.snapshots || [] };
      location.hash = '#/project/' + id;
    } catch (e) { toast(e.message, 'error'); }
  },
  async runBackup() {
    if (!state.currentProject) return;
    const btn = document.querySelector('#tab-snapshots button');
    if (btn) { btn.disabled = true; btn.textContent = '备份中…'; }
    try {
      const r = await jfetch('/api/projects/' + state.currentProject.id + '/backup', { method: 'POST', body: JSON.stringify({ kind: 'incremental' }) });
      toast('备份完成：' + (r.msgCount || 0) + ' 个文件 · ' + fmtSize(r.sizeBytes));
      await this.openProject(state.currentProject.id);
    } catch (e) { toast(e.message, 'error'); }
    finally { if (btn) { btn.disabled = false; btn.textContent = '▶ 立即备份'; } }
  },
  async restoreProject() {
    if (!state.currentProject) return;
    const snapId = $('p-restore-snap').value;
    const outDir = $('p-restore-dir').value;
    if (!snapId || !outDir) return toast('请选择快照并填写恢复目录', 'error');
    try {
      const r = await jfetch('/api/projects/' + state.currentProject.id + '/restore', { method: 'POST', body: JSON.stringify({ snapId, outDir }) });
      toast('已恢复 ' + r.sessions + ' 个文件/目录');
    } catch (e) { toast(e.message, 'error'); }
  },
  async files(snapId) {
    if (!state.currentProject) return;
    try {
      const r = await jfetch('/api/projects/' + state.currentProject.id + '/files?snap=' + encodeURIComponent(snapId));
      renderFiles(r.files || [], snapId);
    } catch (e) { toast(e.message, 'error'); }
  },
  async createSchedule() {
    try {
      const body = { project: $('ns-project').value, schedule: $('ns-schedule').value, kind: $('ns-kind').value, enabled: $('ns-enabled').checked };
      await jfetch('/api/schedules', { method: 'POST', body: JSON.stringify(body) });
      toast('计划已保存');
      await this.refresh();
      UI.go('schedules');
    } catch (e) { toast(e.message, 'error'); }
  },
  async deleteSchedule(id) {
    if (!confirm('确定删除该定时计划？')) return;
    try {
      await jfetch('/api/schedules/' + id, { method: 'DELETE' });
      await this.refresh();
    } catch (e) { toast(e.message, 'error'); }
  },
  async changeAdminPass() {
    try {
      const body = { oldPassword: $('st-old').value, newPassword: $('st-new').value };
      if ($('st-new').value !== $('st-new2').value) throw new Error('两次新口令不一致');
      await jfetch('/api/admin/pass', { method: 'POST', body: JSON.stringify(body) });
      toast('口令已修改，请重新登录');
      setTimeout(() => API.logout(), 1200);
    } catch (e) { toast(e.message, 'error'); }
  },
};

function renderDashboard() {
  $('st-projects').textContent = state.stats.projects || 0;
  $('st-snapshots').textContent = state.stats.snapshots || 0;
  $('st-size').textContent = fmtSize(state.stats.sizeBytes);
  $('st-last').textContent = state.stats.lastTime ? fmtDate(state.stats.lastTime) : '-';

  const recent = state.projects.filter((p) => p.lastTime).sort((a, b) => b.lastTime - a.lastTime).slice(0, 5);
  const box = $('recent-list');
  if (!recent.length) { box.innerHTML = '<p class="muted empty">暂无备份记录</p>'; return; }
  box.innerHTML = recent.map((p) => `<div class="snapshot-row">
    <div><strong>${p.name}</strong><div class="snapshot-meta">${p.source}</div></div>
    <div class="snapshot-meta">${fmtDate(p.lastTime)} · ${p.snapshotCount} 个快照</div>
  </div>`).join('');
}

function renderProjects() {
  const box = $('projects-list');
  if (!state.projects.length) { box.innerHTML = '<p class="muted empty">还没有备份项目，点击右上角新建一个。</p>'; return; }
  box.innerHTML = state.projects.map((p) => {
    const status = p.locked ? 'tag bad' : 'tag ok';
    const statusText = p.locked ? '未解锁' : '已解锁';
    return `<div class="project-card" onclick="API.openProject('${p.id}')">
      <div class="row"><h3>${p.name}</h3><span class="${status}">${statusText}</span></div>
      <div class="path">${p.source}</div>
      <div class="meta">快照 ${p.snapshotCount || 0} · 最近 ${p.lastTime ? fmtDate(p.lastTime) : '无'}</div>
    </div>`;
  }).join('');
}

function renderProject() {
  const p = state.currentProject;
  if (!p) return;
  $('p-title').textContent = p.name;
  const status = p.locked ? 'tag bad' : 'tag ok';
  $('p-status').className = 'tag ' + (p.locked ? 'bad' : 'ok');
  $('p-status').textContent = p.locked ? '锁定' : '已解锁';

  const lockBox = $('p-lock');
  if (p.locked) {
    lockBox.classList.remove('hidden');
    $('p-body').classList.add('hidden');
    lockBox.innerHTML = `<h3>项目已加密</h3><p class="muted">请输入该项目的备份口令或恢复代码以解锁。</p>
      <input id="p-secret" type="password" placeholder="口令 / 恢复代码" />
      <div class="row"><button class="btn btn-primary" onclick="API.unlockProject('${p.id}')">解锁</button></div>`;
  } else {
    lockBox.classList.add('hidden');
    $('p-body').classList.remove('hidden');
    renderSnapshots();
    renderSnapSelect();
    UI.loadSnapshotFiles();
  }
}

function renderSnapshots() {
  const snaps = (state.currentProject.snapshots || []).slice().reverse();
  const box = $('p-snapshots');
  if (!snaps.length) { box.innerHTML = '<p class="muted empty">暂无快照，点击“立即备份”开始。</p>'; return; }
  box.innerHTML = snaps.map((s) => `<div class="snapshot-row">
    <div><strong>${fmtDate(s.time)}</strong><div class="snapshot-meta">${s.type || 'incremental'} · ${s.msgCount || 0} 项 · ${fmtSize(s.sizeBytes)}</div></div>
    <span class="tag ok">正常</span>
  </div>`).join('');
}

function renderSnapSelect() {
  const snaps = (state.currentProject.snapshots || []).slice().reverse();
  const sel = $('p-snap-select');
  sel.innerHTML = snaps.map((s) => `<option value="${s.id}">${fmtDate(s.time)} · ${fmtSize(s.sizeBytes)}</option>`).join('');
  if (snaps.length && !sel.value) sel.value = snaps[0].id;
}

function renderFiles(files, snapId) {
  const box = $('p-files');
  if (!files.length) { box.innerHTML = '<p class="muted empty">该快照为空。</p>'; return; }
  box.innerHTML = files.map((f) => {
    const icon = f.type === 'dir' ? '📁' : '📄';
    return `<div class="file-row">
      <div class="file-icon">${icon}</div>
      <div class="file-name">${f.name}</div>
      <div class="file-size">${f.type === 'dir' ? '-' : fmtSize(f.size)}</div>
      <div class="file-date">${f.mtime ? fmtDate(f.mtime) : '-'}</div>
    </div>`;
  }).join('');
}

function renderSchedules() {
  const box = $('schedules-list');
  const opts = state.projects.map((p) => `<option value="${p.id}">${p.name}</option>`).join('');
  $('ns-project').innerHTML = opts;
  if (!state.schedules.length) { box.innerHTML = '<p class="muted empty">暂无定时计划。</p>'; return; }
  box.innerHTML = state.schedules.map((s) => {
    const p = state.projects.find((x) => x.id === s.account) || { name: s.account };
    const status = s.status === 'failed' ? 'tag bad' : s.status === 'skipped' ? 'tag warn' : 'tag ok';
    return `<div class="schedule-row">
      <div><strong>${p.name}</strong><div class="snapshot-meta">${s.schedule} · ${s.kind} · 下次 ${fmtDate(s.nextAt)}</div></div>
      <div class="row"><span class="${status}">${s.status || '正常'}</span><button class="btn btn-ghost btn-sm" onclick="API.deleteSchedule('${s.id}')">删除</button></div>
    </div>`;
  }).join('');
}

function router() {
  if (!state.admin) return;
  const hash = location.hash.slice(1) || '/';
  $('sidebar').classList.remove('open');

  if (hash === '/' || hash === '') {
    showViews(['view-home']);
    UI.setTitle('仪表盘');
    setActive('home');
    renderDashboard();
  } else if (hash === '/projects') {
    showViews(['view-projects']);
    UI.setTitle('备份项目');
    setActive('projects');
    renderProjects();
  } else if (hash === '/new-project') {
    showViews(['view-new-project']);
    UI.setTitle('新建备份项目');
    setActive('projects');
  } else if (hash === '/schedules') {
    showViews(['view-schedules']);
    UI.setTitle('定时备份计划');
    setActive('schedules');
    renderSchedules();
  } else if (hash === '/new-schedule') {
    showViews(['view-new-schedule']);
    UI.setTitle('新建定时计划');
    setActive('schedules');
    renderSchedules();
  } else if (hash === '/settings') {
    showViews(['view-settings']);
    UI.setTitle('设置');
    setActive('settings');
  } else if (hash.startsWith('/project/')) {
    const id = hash.split('/project/')[1];
    if (!state.currentProject || state.currentProject.id !== id) {
      API.openProject(id);
      return;
    }
    showViews(['view-project']);
    UI.setTitle(state.currentProject.name);
    setActive('projects');
    renderProject();
    UI.pTab(state.currentTab);
  } else {
    UI.go('home');
  }
}

window.addEventListener('hashchange', router);
API.init();
